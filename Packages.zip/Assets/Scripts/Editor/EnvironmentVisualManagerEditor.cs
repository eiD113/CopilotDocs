#if UNITY_EDITOR
using Building.Visuals;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(EnvironmentVisualManager))]
public sealed class EnvironmentVisualManagerEditor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        EditorGUILayout.Space();
        EditorGUILayout.HelpBox(
            "Enable Scene Click Picker, then click cells directly in Scene view. " +
            "Hold Alt to orbit the camera. Press Esc to disable picker mode.",
            MessageType.Info
        );

        EnvironmentVisualManager manager = (EnvironmentVisualManager)target;
        bool isEnabled = EnvironmentVisualScenePicker.IsEnabledFor(manager);

        Color previousColor = GUI.backgroundColor;
        GUI.backgroundColor = isEnabled ? new Color(0.45f, 0.9f, 0.45f) : previousColor;

        if (GUILayout.Button(isEnabled ? "Disable Scene Click Picker" : "Enable Scene Click Picker"))
        {
            EnvironmentVisualScenePicker.SetEnabled(manager, !isEnabled);
        }

        GUI.backgroundColor = previousColor;

        if (GUILayout.Button("Rebuild Cell Visual Lookup Now"))
        {
            manager.RebuildLookup();
            EditorUtility.SetDirty(manager);
        }
    }
}

[InitializeOnLoad]
public static class EnvironmentVisualScenePicker
{
    private static EnvironmentVisualManager activeManager;

    private static readonly Color HoverFillColor = new Color(0.2f, 0.8f, 1f, 0.10f);
    private static readonly Color HoverOutlineColor = new Color(0.2f, 0.8f, 1f, 1f);

    static EnvironmentVisualScenePicker()
    {
        SceneView.duringSceneGui += OnSceneGUI;
    }

    public static bool IsEnabledFor(EnvironmentVisualManager manager)
    {
        return activeManager == manager;
    }

    public static void SetEnabled(EnvironmentVisualManager manager, bool enabled)
    {
        if (enabled)
        {
            activeManager = manager;
            activeManager.RebuildLookup();
        }
        else if (activeManager == manager)
        {
            activeManager = null;
        }

        SceneView.RepaintAll();
    }

    private static void OnSceneGUI(SceneView sceneView)
    {
        if (Application.isPlaying)
        {
            return;
        }

        if (activeManager == null)
        {
            return;
        }

        if (activeManager.GridManager == null)
        {
            return;
        }

        Event currentEvent = Event.current;

        if (currentEvent == null)
        {
            return;
        }

        if (currentEvent.type == EventType.KeyDown && currentEvent.keyCode == KeyCode.Escape)
        {
            activeManager = null;
            currentEvent.Use();
            SceneView.RepaintAll();
            return;
        }

        GridManager gridManager = activeManager.GridManager;

        if (!TryGetHoveredCell(gridManager, currentEvent.mousePosition, out Vector2Int hoveredCell))
        {
            return;
        }

        if (!activeManager.TryGetCellVisual(hoveredCell.x, hoveredCell.y, out CellVisualView hoveredView))
        {
            return;
        }

        DrawHoveredCellOutline(gridManager, activeManager.CellVisualZ, hoveredCell);
        DrawHoveredCellLabel(gridManager, activeManager.CellVisualZ, hoveredCell);

        if (!currentEvent.alt)
        {
            int controlId = GUIUtility.GetControlID(FocusType.Passive);
            HandleUtility.AddDefaultControl(controlId);
        }

        if (currentEvent.type == EventType.MouseMove)
        {
            SceneView.RepaintAll();
        }

        if (currentEvent.type == EventType.MouseDown && currentEvent.button == 0 && !currentEvent.alt)
        {
            activeManager.RebuildLookup();

            if (activeManager.TryGetCellVisual(hoveredCell.x, hoveredCell.y, out CellVisualView clickedView))
            {
                Selection.activeGameObject = clickedView.gameObject;
                EditorGUIUtility.PingObject(clickedView.gameObject);
            }

            currentEvent.Use();
        }
    }

    private static bool TryGetHoveredCell(GridManager gridManager, Vector2 mousePosition, out Vector2Int logicalCell)
    {
        logicalCell = default;

        Ray ray = HandleUtility.GUIPointToWorldRay(mousePosition);
        Plane gridPlane = new Plane(
            gridManager.GetGridPlaneNormal(),
            gridManager.GetGridPlaneWorldPosition()
        );

        if (!gridPlane.Raycast(ray, out float enter))
        {
            return false;
        }

        Vector3 worldPoint = ray.GetPoint(enter);
        return gridManager.TryGetCellFromWorldPoint(worldPoint, out logicalCell);
    }

    private static void DrawHoveredCellOutline(GridManager gridManager, float z, Vector2Int logicalCell)
    {
        Vector3 origin = gridManager.GetCellWorldOrigin(logicalCell.x, logicalCell.y);
        float size = gridManager.CellSize;

        Vector3[] corners = new Vector3[4];
        corners[0] = new Vector3(origin.x, origin.y, z);
        corners[1] = new Vector3(origin.x + size, origin.y, z);
        corners[2] = new Vector3(origin.x + size, origin.y + size, z);
        corners[3] = new Vector3(origin.x, origin.y + size, z);

        Handles.DrawSolidRectangleWithOutline(corners, HoverFillColor, HoverOutlineColor);
    }

    private static void DrawHoveredCellLabel(GridManager gridManager, float z, Vector2Int logicalCell)
    {
        Vector3 center = gridManager.GetCellWorldCenter(logicalCell.x, logicalCell.y);
        Vector3 labelPosition = new Vector3(center.x, center.y, z);

        GUIStyle style = new GUIStyle(EditorStyles.boldLabel);
        style.normal.textColor = Color.white;
        style.alignment = TextAnchor.MiddleCenter;

        Handles.Label(labelPosition, $"Cell {logicalCell.x},{logicalCell.y}", style);
    }
}
#endif