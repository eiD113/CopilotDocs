using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

public class GridManager : MonoBehaviour
{
    private enum TerrainVisualType
    {
        None,
        Sky,
        Surface,
        Earth
    }

    [Header("Grid Size")]
    [SerializeField] private int width = 42;
    [SerializeField] private int height = 60;
    [SerializeField] private float cellSize = 1f;

    [Header("Build Area")]
    [SerializeField] private int buildAreaX = 10;
    [SerializeField] private int buildAreaY = 9;
    [SerializeField] private int buildAreaWidth = 22;
    [SerializeField] private int buildAreaHeight = 48;

    [Header("Terrain Blockout")]
    [SerializeField] private bool generateTerrainVisuals = true;
    [SerializeField] private int surfaceRowY = 6;
    [SerializeField] private float terrainBlockDepth = 1f;
    [SerializeField] private float terrainZOffset = 0f;
    [SerializeField] private bool hideGeneratedBlocksInHierarchy = false;

    [SerializeField] private Color skyBlockColor = new Color(0.45f, 0.75f, 1f, 1f);
    [SerializeField] private Color surfaceBlockColor = new Color(0.25f, 0.8f, 0.25f, 1f);
    [SerializeField] private Color earthBlockColor = new Color(0.45f, 0.28f, 0.12f, 1f);

    [Header("Debug")]
    [SerializeField] private bool drawGrid = true;
    [SerializeField] private bool fillCells = true;
    [SerializeField] private bool drawBuildAreaOutline = true;
    [SerializeField] private bool drawAxisLabels = true;

    private GridCell[,] cells;

    private const string TerrainVisualRootName = "__TerrainVisuals";

    private Transform terrainVisualRoot;
    private Material generatedTerrainMaterial;
    private MaterialPropertyBlock materialPropertyBlock;

    public int Width => width;
    public int Height => height;
    public float CellSize => cellSize;

    public int BuildAreaX => buildAreaX;
    public int BuildAreaY => buildAreaY;
    public int BuildAreaWidth => buildAreaWidth;
    public int BuildAreaHeight => buildAreaHeight;
    public int SurfaceRowY => surfaceRowY;

    private void Awake()
    {
        ClampSettings();
        RebuildGrid();
    }

    private void Start()
    {
        RebuildTerrainVisuals();
    }

    private void OnValidate()
    {
        ClampSettings();
        RebuildGrid();
    }

    private void OnDestroy()
    {
        if (generatedTerrainMaterial != null)
        {
            if (Application.isPlaying)
            {
                Destroy(generatedTerrainMaterial);
            }
            else
            {
                DestroyImmediate(generatedTerrainMaterial);
            }
        }
    }

    public void RebuildGrid()
    {
        ClampSettings();

        cells = new GridCell[width, height];

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                CellBaseType baseType = IsInsideBuildArea(x, y)
                    ? CellBaseType.Buildable
                    : CellBaseType.Blocked;

                cells[x, y] = GridCell.Create(baseType);
            }
        }
    }

    public bool IsInside(int x, int y)
    {
        return x >= 0 && x < width && y >= 0 && y < height;
    }

    public bool IsInsideBuildArea(int x, int y)
    {
        return x >= buildAreaX
            && x < buildAreaX + buildAreaWidth
            && y >= buildAreaY
            && y < buildAreaY + buildAreaHeight;
    }

    public GridCell GetCell(int x, int y)
    {
        if (!IsInside(x, y))
        {
            Debug.LogError($"GetCell failed. ({x}, {y}) is outside the grid.");
            return default;
        }

        return cells[x, y];
    }

    public void SetCell(int x, int y, GridCell cell)
    {
        if (!IsInside(x, y))
        {
            Debug.LogError($"SetCell failed. ({x}, {y}) is outside the grid.");
            return;
        }

        cells[x, y] = cell;
    }

    public bool IsAreaInsideGrid(int originX, int originY, int widthInCells, int heightInCells)
{
    if (widthInCells < 1 || heightInCells < 1)
    {
        return false;
    }

    int maxX = originX + widthInCells - 1;
    int maxY = originY + heightInCells - 1;

    return IsInside(originX, originY) && IsInside(maxX, maxY);
}

public bool IsAreaInsideBuildArea(int originX, int originY, int widthInCells, int heightInCells)
{
    if (!IsAreaInsideGrid(originX, originY, widthInCells, heightInCells))
    {
        return false;
    }

    for (int y = originY; y < originY + heightInCells; y++)
    {
        for (int x = originX; x < originX + widthInCells; x++)
        {
            if (!IsInsideBuildArea(x, y))
            {
                return false;
            }
        }
    }

    return true;
}

public bool IsAreaFree(int originX, int originY, int widthInCells, int heightInCells)
{
    EnsureGridExists();

    if (!IsAreaInsideGrid(originX, originY, widthInCells, heightInCells))
    {
        return false;
    }

    for (int y = originY; y < originY + heightInCells; y++)
    {
        for (int x = originX; x < originX + widthInCells; x++)
        {
            GridCell cell = GetCell(x, y);

            if (cell.OccupantType != CellOccupantType.None)
            {
                return false;
            }
        }
    }

    return true;
}

public void SetAreaOccupant(
    int originX,
    int originY,
    int widthInCells,
    int heightInCells,
    CellOccupantType occupantType,
    int occupantId)
{
    EnsureGridExists();

    if (!IsAreaInsideGrid(originX, originY, widthInCells, heightInCells))
    {
        Debug.LogError(
            $"SetAreaOccupant failed. Area ({originX}, {originY}, {widthInCells}, {heightInCells}) is outside the grid."
        );
        return;
    }

    for (int y = originY; y < originY + heightInCells; y++)
    {
        for (int x = originX; x < originX + widthInCells; x++)
        {
            GridCell cell = GetCell(x, y);
            cell.OccupantType = occupantType;
            cell.OccupantId = occupantId;
            SetCell(x, y, cell);
        }
    }
}

    public bool TryGetCellFromWorldPoint(Vector3 worldPoint, out Vector2Int logicalCell)
{
    logicalCell = default;

    float localX = worldPoint.x - transform.position.x;
    float localY = worldPoint.y - transform.position.y;

    if (localX < 0f || localY < 0f)
    {
        return false;
    }

    int visualColumn = Mathf.FloorToInt(localX / cellSize);
    int visualRow = Mathf.FloorToInt(localY / cellSize);

    int logicalX = (width - 1) - visualColumn;
    int logicalY = (height - 1) - visualRow;

    if (!IsInside(logicalX, logicalY))
    {
        return false;
    }

    logicalCell = new Vector2Int(logicalX, logicalY);
    return true;
}

public Vector3 GetGridPlaneWorldPosition()
{
    return transform.position;
}

public Vector3 GetGridPlaneNormal()
{
    return transform.forward;
}

    private int LogicalXToVisualColumn(int x)
    {
        return (width - 1) - x;
    }

    private int LogicalYToVisualRow(int y)
    {
        return (height - 1) - y;
    }

    public Vector3 GetCellWorldOrigin(int x, int y)
    {
        int visualColumn = LogicalXToVisualColumn(x);
        int visualRow = LogicalYToVisualRow(y);

        return transform.position + new Vector3(
            visualColumn * cellSize,
            visualRow * cellSize,
            0f
        );
    }

    public Vector3 GetCellWorldCenter(int x, int y)
    {
        return GetCellWorldOrigin(x, y) + new Vector3(
            cellSize * 0.5f,
            cellSize * 0.5f,
            0f
        );
    }

    private void RebuildEverything()
    {
        ClampSettings();
        RebuildGrid();
        RebuildTerrainVisuals();
    }

    private void ClampSettings()
    {
        if (width < 1)
        {
            width = 1;
        }

        if (height < 1)
        {
            height = 1;
        }

        if (cellSize <= 0f)
        {
            cellSize = 1f;
        }

        if (buildAreaWidth < 1)
        {
            buildAreaWidth = 1;
        }

        if (buildAreaHeight < 1)
        {
            buildAreaHeight = 1;
        }

        if (buildAreaX < 0)
        {
            buildAreaX = 0;
        }

        if (buildAreaY < 0)
        {
            buildAreaY = 0;
        }

        if (buildAreaX >= width)
        {
            buildAreaX = width - 1;
        }

        if (buildAreaY >= height)
        {
            buildAreaY = height - 1;
        }

        if (buildAreaX + buildAreaWidth > width)
        {
            buildAreaWidth = width - buildAreaX;
        }

        if (buildAreaY + buildAreaHeight > height)
        {
            buildAreaHeight = height - buildAreaY;
        }

        surfaceRowY = Mathf.Clamp(surfaceRowY, 0, height - 1);

        if (terrainBlockDepth <= 0f)
        {
            terrainBlockDepth = 1f;
        }
    }

    private void EnsureGridExists()
    {
        if (cells == null || cells.GetLength(0) != width || cells.GetLength(1) != height)
        {
            RebuildGrid();
        }
    }

    private TerrainVisualType GetTerrainVisualType(int x, int y)
    {
        if (y < surfaceRowY)
        {
            return TerrainVisualType.Sky;
        }

        if (y == surfaceRowY)
        {
            return TerrainVisualType.Surface;
        }

        if (IsInsideBuildArea(x, y))
        {
            return TerrainVisualType.None;
        }

        return TerrainVisualType.Earth;
    }

    private Color GetTerrainVisualColor(TerrainVisualType type)
    {
        switch (type)
        {
            case TerrainVisualType.Sky:
                return skyBlockColor;

            case TerrainVisualType.Surface:
                return surfaceBlockColor;

            case TerrainVisualType.Earth:
                return earthBlockColor;

            default:
                return Color.clear;
        }
    }

    private void RebuildTerrainVisuals()
    {
        ClearTerrainVisuals();

        if (!generateTerrainVisuals)
        {
            return;
        }

        if (!gameObject.scene.IsValid())
        {
            return;
        }

        EnsureTerrainVisualRoot();

        Material sharedMaterial = GetOrCreateGeneratedTerrainMaterial();

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                TerrainVisualType visualType = GetTerrainVisualType(x, y);

                if (visualType == TerrainVisualType.None)
                {
                    continue;
                }

                CreateTerrainBlock(x, y, sharedMaterial, GetTerrainVisualColor(visualType));
            }
        }
    }

    private void EnsureTerrainVisualRoot()
    {
        if (terrainVisualRoot == null)
        {
            Transform found = transform.Find(TerrainVisualRootName);

            if (found != null)
            {
                terrainVisualRoot = found;
            }
            else
            {
                GameObject root = new GameObject(TerrainVisualRootName);
                root.transform.SetParent(transform, false);
                terrainVisualRoot = root.transform;
            }
        }

        terrainVisualRoot.hideFlags = hideGeneratedBlocksInHierarchy
            ? HideFlags.HideInHierarchy
            : HideFlags.None;
    }

    private void ClearTerrainVisuals()
    {
        if (terrainVisualRoot == null)
        {
            Transform found = transform.Find(TerrainVisualRootName);
            if (found != null)
            {
                terrainVisualRoot = found;
            }
        }

        if (terrainVisualRoot == null)
        {
            return;
        }

        for (int i = terrainVisualRoot.childCount - 1; i >= 0; i--)
        {
            DestroySafely(terrainVisualRoot.GetChild(i).gameObject);
        }
    }

    private void CreateTerrainBlock(int x, int y, Material sharedMaterial, Color color)
    {
        GameObject block = GameObject.CreatePrimitive(PrimitiveType.Cube);
        block.name = $"Terrain_{x}_{y}";
        block.transform.SetParent(terrainVisualRoot, true);
        block.transform.position = GetCellWorldCenter(x, y) + new Vector3(0f, 0f, terrainZOffset);
        block.transform.rotation = Quaternion.identity;
        block.transform.localScale = new Vector3(cellSize, cellSize, terrainBlockDepth);
        block.hideFlags = hideGeneratedBlocksInHierarchy ? HideFlags.HideInHierarchy : HideFlags.None;

        Collider collider = block.GetComponent<Collider>();
        if (collider != null)
        {
            DestroySafely(collider);
        }

        Renderer renderer = block.GetComponent<Renderer>();
        if (renderer != null)
        {
            renderer.sharedMaterial = sharedMaterial;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            renderer.receiveShadows = false;
            ApplyRendererColor(renderer, color);
        }
    }

    private Material GetOrCreateGeneratedTerrainMaterial()
    {
        if (generatedTerrainMaterial != null)
        {
            return generatedTerrainMaterial;
        }

        Shader shader = Shader.Find("Universal Render Pipeline/Unlit");
        if (shader == null)
        {
            shader = Shader.Find("Unlit/Color");
        }

        if (shader == null)
        {
            shader = Shader.Find("Standard");
        }

        generatedTerrainMaterial = new Material(shader);
        generatedTerrainMaterial.name = "Generated_Terrain_Block_Material";

        return generatedTerrainMaterial;
    }

    private void ApplyRendererColor(Renderer renderer, Color color)
    {
        if (renderer == null)
        {
            return;
        }

        if (materialPropertyBlock == null)
        {
            materialPropertyBlock = new MaterialPropertyBlock();
        }

        materialPropertyBlock.Clear();
        materialPropertyBlock.SetColor("_BaseColor", color);
        materialPropertyBlock.SetColor("_Color", color);
        renderer.SetPropertyBlock(materialPropertyBlock);
    }

    private void DestroySafely(Object target)
    {
        if (target == null)
        {
            return;
        }

        if (Application.isPlaying)
        {
            Destroy(target);
        }
        else
        {
            DestroyImmediate(target);
        }
    }

    private Color GetCellDebugColor(GridCell cell)
    {
        if (cell.OccupantType != CellOccupantType.None)
        {
            return new Color(1f, 1f, 0f, 0.20f);
        }

        if (cell.BaseType == CellBaseType.Blocked)
        {
            return new Color(1f, 0f, 0f, 0.20f);
        }

        return new Color(0f, 1f, 0f, 0.20f);
    }

    private void DrawBuildAreaOutline()
    {
        if (!drawBuildAreaOutline || buildAreaWidth <= 0 || buildAreaHeight <= 0)
        {
            return;
        }

        Vector3 a = GetCellWorldOrigin(buildAreaX, buildAreaY);
        Vector3 b = GetCellWorldOrigin(buildAreaX + buildAreaWidth - 1, buildAreaY + buildAreaHeight - 1);

        float minX = Mathf.Min(a.x, b.x);
        float maxX = Mathf.Max(a.x, b.x) + cellSize;
        float minY = Mathf.Min(a.y, b.y);
        float maxY = Mathf.Max(a.y, b.y) + cellSize;

        Vector3 topLeft = new Vector3(minX, maxY, 0f);
        Vector3 topRight = new Vector3(maxX, maxY, 0f);
        Vector3 bottomLeft = new Vector3(minX, minY, 0f);
        Vector3 bottomRight = new Vector3(maxX, minY, 0f);

        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(topLeft, topRight);
        Gizmos.DrawLine(topRight, bottomRight);
        Gizmos.DrawLine(bottomRight, bottomLeft);
        Gizmos.DrawLine(bottomLeft, topLeft);
    }

#if UNITY_EDITOR
    private void DrawAxisLabels()
    {
        if (!drawAxisLabels)
        {
            return;
        }

        GUIStyle style = new GUIStyle(EditorStyles.boldLabel);
        style.normal.textColor = Color.white;
        style.alignment = TextAnchor.MiddleCenter;

        float offset = cellSize * 0.6f;

        for (int x = 0; x < width; x++)
        {
            Vector3 labelPosition = GetCellWorldCenter(x, 0) + new Vector3(0f, offset, 0f);
            Handles.Label(labelPosition, x.ToString(), style);
        }

        for (int y = 0; y < height; y++)
        {
            Vector3 labelPosition = GetCellWorldCenter(0, y) + new Vector3(offset, 0f, 0f);
            Handles.Label(labelPosition, y.ToString(), style);
        }
    }
#endif

    private void OnDrawGizmos()
    {
        if (!drawGrid)
        {
            return;
        }

        ClampSettings();
        EnsureGridExists();

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                Vector3 center = GetCellWorldCenter(x, y);
                Vector3 size = new Vector3(cellSize, cellSize, 0.01f);

                if (fillCells)
                {
                    Gizmos.color = GetCellDebugColor(cells[x, y]);
                    Gizmos.DrawCube(center, size);
                }

                Gizmos.color = Color.white;
                Gizmos.DrawWireCube(center, size);
            }
        }

        DrawBuildAreaOutline();

#if UNITY_EDITOR
        DrawAxisLabels();
#endif
    }
}