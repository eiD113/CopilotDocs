using System;

[Serializable]
public struct GridCell
{
    public CellBaseType BaseType;
    public CellOccupantType OccupantType;
    public int OccupantId;

    public static GridCell Create(CellBaseType baseType)
    {
        return new GridCell
        {
            BaseType = baseType,
            OccupantType = CellOccupantType.None,
            OccupantId = -1
        };
    }

    public static GridCell CreateDefault()
    {
        return Create(CellBaseType.Buildable);
    }
}