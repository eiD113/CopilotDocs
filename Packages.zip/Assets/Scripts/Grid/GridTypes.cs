public enum CellBaseType
{
    Buildable,
    Blocked
}

public enum CellOccupantType
{
    None,
    Room,
    Elevator
}