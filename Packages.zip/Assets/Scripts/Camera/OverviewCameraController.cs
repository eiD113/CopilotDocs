using UnityEngine;
using UnityEngine.InputSystem;
using Unity.Cinemachine;

public class OverviewCameraController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private GridManager gridManager;
    [SerializeField] private Camera outputCamera;
    [SerializeField] private CinemachineCamera cmCamera;

    [Header("Keyboard Pan")]
    [SerializeField] private float panSpeed = 12f;

    [Header("Zoom")]
    [SerializeField] private float mouseWheelZoomStep = 1f;
    [SerializeField] private float gamepadZoomSpeed = 8f;
    [SerializeField] private float minOrthographicSize = 2f;
    [SerializeField] private float maxOrthographicSizeOverride = 0f;

    [Header("Hidden Side Columns")]
    [SerializeField] private int hiddenColumnsOnVisualLeft = 5;
    [SerializeField] private int hiddenColumnsOnVisualRight = 5;

    [Header("Locks")]
    [SerializeField] private bool clampOnStart = true;
    [SerializeField] private bool lockZPosition = true;
    [SerializeField] private bool lockRotation = true;

    [Header("Debug")]
    [SerializeField] private bool drawClampGizmo = true;

    private float fixedZ;
    private Quaternion fixedRotation;
    private bool warnedAboutProjection;

    private void Reset()
    {
        AutoAssignReferences();
        CacheLocks();
    }

    private void Awake()
    {
        AutoAssignReferences();
        CacheLocks();
    }

    private void Start()
    {
        AutoAssignReferences();
        CacheLocks();

        ClampZoomToGrid();

        if (clampOnStart)
        {
            ClampToGrid();
        }
    }

    private void OnValidate()
    {
        if (panSpeed < 0f)
        {
            panSpeed = 0f;
        }

        if (mouseWheelZoomStep < 0f)
        {
            mouseWheelZoomStep = 0f;
        }

        if (gamepadZoomSpeed < 0f)
        {
            gamepadZoomSpeed = 0f;
        }

        if (minOrthographicSize < 0.01f)
        {
            minOrthographicSize = 0.01f;
        }

        if (maxOrthographicSizeOverride < 0f)
        {
            maxOrthographicSizeOverride = 0f;
        }

        if (hiddenColumnsOnVisualLeft < 0)
        {
            hiddenColumnsOnVisualLeft = 0;
        }

        if (hiddenColumnsOnVisualRight < 0)
        {
            hiddenColumnsOnVisualRight = 0;
        }
    }

    private void Update()
    {
        HandleZoom();
        HandleKeyboardPan();
        ClampZoomToGrid();
        ClampToGrid();
        ApplyLocks();
    }

    private void AutoAssignReferences()
    {
        if (gridManager == null)
        {
            gridManager = FindFirstObjectByType<GridManager>();
        }

        if (outputCamera == null)
        {
            outputCamera = Camera.main;
        }

        if (cmCamera == null)
        {
            cmCamera = GetComponent<CinemachineCamera>();
        }
    }

    private void CacheLocks()
    {
        fixedZ = transform.position.z;
        fixedRotation = transform.rotation;
    }

    private void HandleKeyboardPan()
    {
        Vector2 input = Vector2.zero;

        Keyboard keyboard = Keyboard.current;
        if (keyboard != null)
        {
            if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed)
                input.x += 1f;

            if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed)
                input.x -= 1f;

            if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed)
                input.y -= 1f;

            if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed)
                input.y += 1f;
        }

        Gamepad gamepad = Gamepad.current;
        if (gamepad != null)
        {
            input += gamepad.leftStick.ReadValue();
        }

        if (input.sqrMagnitude > 1f)
        {
            input.Normalize();
        }

        Vector3 move = new Vector3(input.x, input.y, 0f);
        transform.position += move * panSpeed * Time.deltaTime;
    }

    private void HandleZoom()
    {
        float newSize = GetCurrentOrthographicSize();

        Mouse mouse = Mouse.current;
        if (mouse != null)
        {
            float scrollSteps = mouse.scroll.ReadValue().y / 120f;
            if (Mathf.Abs(scrollSteps) > 0.001f)
            {
                newSize -= scrollSteps * mouseWheelZoomStep;
            }
        }

        Gamepad gamepad = Gamepad.current;
        if (gamepad != null)
        {
            float triggerZoom = gamepad.rightTrigger.ReadValue() - gamepad.leftTrigger.ReadValue();
            if (Mathf.Abs(triggerZoom) > 0.001f)
            {
                newSize -= triggerZoom * gamepadZoomSpeed * Time.deltaTime;
            }
        }

        SetCurrentOrthographicSize(newSize);
    }

    private void ClampZoomToGrid()
    {
        if (gridManager == null || outputCamera == null)
        {
            return;
        }

        if (!IsOrthographicSetupValid())
        {
            return;
        }

        if (!TryGetAllowedBounds(out float allowedMinX, out float allowedMaxX, out float allowedMinY, out float allowedMaxY))
        {
            return;
        }

        float allowedWidth = allowedMaxX - allowedMinX;
        float allowedHeight = allowedMaxY - allowedMinY;

        float aspect = outputCamera.aspect;
        if (aspect <= 0f)
        {
            return;
        }

        float maxByHeight = allowedHeight * 0.5f;
        float maxByWidth = (allowedWidth * 0.5f) / aspect;

        float computedMax = Mathf.Min(maxByHeight, maxByWidth);

        if (maxOrthographicSizeOverride > 0f)
        {
            computedMax = Mathf.Min(computedMax, maxOrthographicSizeOverride);
        }

        computedMax = Mathf.Max(0.01f, computedMax);

        float effectiveMin = Mathf.Min(minOrthographicSize, computedMax);
        float clampedSize = Mathf.Clamp(GetCurrentOrthographicSize(), effectiveMin, computedMax);

        SetCurrentOrthographicSize(clampedSize);
    }

    private void ClampToGrid()
    {
        if (gridManager == null || outputCamera == null)
        {
            return;
        }

        if (!IsOrthographicSetupValid())
        {
            return;
        }

        if (!TryGetAllowedBounds(out float allowedMinX, out float allowedMaxX, out float allowedMinY, out float allowedMaxY))
        {
            return;
        }

        float halfHeight = GetCurrentOrthographicSize();
        float halfWidth = halfHeight * outputCamera.aspect;

        float minCenterX = allowedMinX + halfWidth;
        float maxCenterX = allowedMaxX - halfWidth;
        float minCenterY = allowedMinY + halfHeight;
        float maxCenterY = allowedMaxY - halfHeight;

        Vector3 clampedPosition = transform.position;

        if (minCenterX > maxCenterX)
        {
            clampedPosition.x = (allowedMinX + allowedMaxX) * 0.5f;
        }
        else
        {
            clampedPosition.x = Mathf.Clamp(clampedPosition.x, minCenterX, maxCenterX);
        }

        if (minCenterY > maxCenterY)
        {
            clampedPosition.y = (allowedMinY + allowedMaxY) * 0.5f;
        }
        else
        {
            clampedPosition.y = Mathf.Clamp(clampedPosition.y, minCenterY, maxCenterY);
        }

        transform.position = clampedPosition;
    }

    private bool TryGetAllowedBounds(out float allowedMinX, out float allowedMaxX, out float allowedMinY, out float allowedMaxY)
    {
        allowedMinX = 0f;
        allowedMaxX = 0f;
        allowedMinY = 0f;
        allowedMaxY = 0f;

        if (gridManager == null)
        {
            return false;
        }

        float cellSize = gridManager.CellSize;

        Vector3 cornerA = gridManager.GetCellWorldOrigin(0, 0);
        Vector3 cornerB = gridManager.GetCellWorldOrigin(gridManager.Width - 1, gridManager.Height - 1);

        float fullMinX = Mathf.Min(cornerA.x, cornerB.x);
        float fullMaxX = Mathf.Max(cornerA.x, cornerB.x) + cellSize;
        float fullMinY = Mathf.Min(cornerA.y, cornerB.y);
        float fullMaxY = Mathf.Max(cornerA.y, cornerB.y) + cellSize;

        // GridManager mirrors logical X into world space.
        // Because of that:
        // visual left  = world max X
        // visual right = world min X
        allowedMinX = fullMinX + (hiddenColumnsOnVisualRight * cellSize);
        allowedMaxX = fullMaxX - (hiddenColumnsOnVisualLeft * cellSize);
        allowedMinY = fullMinY;
        allowedMaxY = fullMaxY;

        return true;
    }

    private bool IsOrthographicSetupValid()
    {
        if (!outputCamera.orthographic)
        {
            if (!warnedAboutProjection)
            {
                Debug.LogWarning("OverviewCameraController requires the output camera to use Orthographic projection.");
                warnedAboutProjection = true;
            }

            return false;
        }

        return true;
    }

    private float GetCurrentOrthographicSize()
    {
        if (cmCamera != null)
        {
            return cmCamera.Lens.OrthographicSize;
        }

        if (outputCamera != null)
        {
            return outputCamera.orthographicSize;
        }

        return 5f;
    }

    private void SetCurrentOrthographicSize(float size)
    {
        size = Mathf.Max(0.01f, size);

        if (cmCamera != null)
        {
            LensSettings lens = cmCamera.Lens;
            lens.OrthographicSize = size;
            cmCamera.Lens = lens;
        }

        if (outputCamera != null && outputCamera.orthographic)
        {
            outputCamera.orthographicSize = size;
        }
    }

    private void ApplyLocks()
    {
        Vector3 pos = transform.position;

        if (lockZPosition)
        {
            pos.z = fixedZ;
        }

        transform.position = pos;

        if (lockRotation)
        {
            transform.rotation = fixedRotation;
        }
    }

    private void OnDrawGizmosSelected()
    {
        if (!drawClampGizmo || gridManager == null)
        {
            return;
        }

        if (!TryGetAllowedBounds(out float allowedMinX, out float allowedMaxX, out float allowedMinY, out float allowedMaxY))
        {
            return;
        }

        Vector3 center = new Vector3(
            (allowedMinX + allowedMaxX) * 0.5f,
            (allowedMinY + allowedMaxY) * 0.5f,
            transform.position.z
        );

        Vector3 size = new Vector3(
            allowedMaxX - allowedMinX,
            allowedMaxY - allowedMinY,
            0.05f
        );

        Gizmos.color = Color.cyan;
        Gizmos.DrawWireCube(center, size);
    }
}