using UnityEngine;

namespace Building.Visuals
{
    [DisallowMultipleComponent]
    [RequireComponent(typeof(SpriteRenderer))]
    public sealed class CellVisualView : MonoBehaviour
    {
        [Header("Grid Coordinates")]
        [SerializeField] private int gridX;
        [SerializeField] private int gridY;

        [Header("Placement")]
        [SerializeField] private float snappedZ = 0f;
        [SerializeField] private bool autoFitToCell = true;

        [Header("Renderers")]
        [SerializeField] private SpriteRenderer mainRenderer;
        [SerializeField] private SpriteRenderer overlayRenderer;

        public int GridX => gridX;
        public int GridY => gridY;
        public Vector2Int GridPosition => new Vector2Int(gridX, gridY);

        public SpriteRenderer MainRenderer => mainRenderer;
        public SpriteRenderer OverlayRenderer => overlayRenderer;

        private void Reset()
        {
            CacheReferences();
        }

        private void OnValidate()
        {
            CacheReferences();

            if (!Application.isPlaying && autoFitToCell)
            {
                TryFitToGridCell();
            }
        }

        public void Initialize(int x, int y)
        {
            gridX = x;
            gridY = y;
        }

        public void SetGridCoordinates(int x, int y)
        {
            gridX = x;
            gridY = y;
        }

        public void SetMainSprite(Sprite sprite)
        {
            if (mainRenderer == null)
            {
                CacheReferences();
            }

            if (mainRenderer == null)
            {
                Debug.LogError($"[{nameof(CellVisualView)}] MainRenderer is missing on {name}.", this);
                return;
            }

            mainRenderer.sprite = sprite;

            if (autoFitToCell)
            {
                TryFitToGridCell();
            }
        }

        public void SetOverlaySprite(Sprite sprite)
        {
            if (overlayRenderer == null)
            {
                return;
            }

            overlayRenderer.sprite = sprite;
            overlayRenderer.enabled = sprite != null;
        }

        public void SetMainColor(Color color)
        {
            if (mainRenderer == null)
            {
                CacheReferences();
            }

            if (mainRenderer == null)
            {
                return;
            }

            mainRenderer.color = color;
        }

        public void SetVisible(bool visible)
        {
            if (mainRenderer != null)
            {
                mainRenderer.enabled = visible;
            }

            if (overlayRenderer != null)
            {
                overlayRenderer.enabled = visible && overlayRenderer.sprite != null;
            }
        }

        [ContextMenu("Clear Visuals")]
        public void ClearVisuals()
        {
            if (mainRenderer != null)
            {
                mainRenderer.sprite = null;
                mainRenderer.color = Color.white;
                mainRenderer.enabled = true;
            }

            if (overlayRenderer != null)
            {
                overlayRenderer.sprite = null;
                overlayRenderer.color = Color.white;
                overlayRenderer.enabled = false;
            }

            transform.localScale = Vector3.one;
        }

        [ContextMenu("Rename To Grid Coordinates")]
        public void RenameToGridCoordinates()
        {
            gameObject.name = $"Cell_{gridX}_{gridY}";
        }

        [ContextMenu("Snap To Grid Coordinates")]
        public void SnapToGridCoordinates()
        {
            GridManager gridManager = FindFirstObjectByType<GridManager>();

            if (gridManager == null)
            {
                Debug.LogError($"[{nameof(CellVisualView)}] No GridManager found in the scene.", this);
                return;
            }

            if (!gridManager.IsInside(gridX, gridY))
            {
                Debug.LogError(
                    $"[{nameof(CellVisualView)}] Grid coordinates ({gridX}, {gridY}) are outside the grid.",
                    this
                );
                return;
            }

            Vector3 cellCenter = gridManager.GetCellWorldCenter(gridX, gridY);
            transform.position = new Vector3(cellCenter.x, cellCenter.y, snappedZ);

            if (autoFitToCell)
            {
                FitToGridCell(gridManager);
            }
        }

        [ContextMenu("Fit To Grid Cell")]
        public void FitToGridCellFromMenu()
        {
            GridManager gridManager = FindFirstObjectByType<GridManager>();

            if (gridManager == null)
            {
                Debug.LogError($"[{nameof(CellVisualView)}] No GridManager found in the scene.", this);
                return;
            }

            FitToGridCell(gridManager);
        }

        [ContextMenu("Snap, Fit And Rename")]
        public void SnapFitAndRename()
        {
            SnapToGridCoordinates();
            RenameToGridCoordinates();
        }

        private void TryFitToGridCell()
        {
            GridManager gridManager = FindFirstObjectByType<GridManager>();

            if (gridManager == null)
            {
                return;
            }

            FitToGridCell(gridManager);
        }

        private void FitToGridCell(GridManager gridManager)
        {
            if (mainRenderer == null)
            {
                CacheReferences();
            }

            if (mainRenderer == null || mainRenderer.sprite == null)
            {
                return;
            }

            Vector2 spriteWorldSize = mainRenderer.sprite.bounds.size;

            if (spriteWorldSize.x <= 0f || spriteWorldSize.y <= 0f)
            {
                Debug.LogWarning(
                    $"[{nameof(CellVisualView)}] Sprite on {name} has invalid bounds size.",
                    this
                );
                return;
            }

            float targetSize = gridManager.CellSize;

            transform.localScale = new Vector3(
                targetSize / spriteWorldSize.x,
                targetSize / spriteWorldSize.y,
                1f
            );
        }

        private void CacheReferences()
        {
            if (mainRenderer == null)
            {
                mainRenderer = GetComponent<SpriteRenderer>();
            }

            if (overlayRenderer == null)
            {
                Transform overlayTransform = transform.Find("Overlay");

                if (overlayTransform != null)
                {
                    overlayRenderer = overlayTransform.GetComponent<SpriteRenderer>();
                }
            }
        }
    }
}