using System.Collections.Generic;
using UnityEngine;

public class BuildPlacementZoneView : MonoBehaviour
{
    [Header("Debug")]
    [SerializeField] private Vector2Int originCell;
    [SerializeField] private Vector2Int sizeInCells;

    private readonly List<Material> runtimeMaterials = new List<Material>();

    public void Initialize(
        GridManager gridManager,
        Vector2Int zoneOriginCell,
        Vector2Int zoneSizeInCells,
        float zOffset,
        float lineThickness,
        float depth,
        Color color)
    {
        originCell = zoneOriginCell;
        sizeInCells = zoneSizeInCells;

        name = $"Zone_{zoneOriginCell.x}_{zoneOriginCell.y}";
        transform.rotation = Quaternion.identity;

        BuildVisual(
            gridManager,
            zoneOriginCell,
            zoneSizeInCells,
            zOffset,
            lineThickness,
            depth,
            color
        );
    }

    private void BuildVisual(
        GridManager gridManager,
        Vector2Int zoneOriginCell,
        Vector2Int zoneSizeInCells,
        float zOffset,
        float lineThickness,
        float depth,
        Color color)
    {
        ClearChildren();

        Vector3 a = gridManager.GetCellWorldOrigin(zoneOriginCell.x, zoneOriginCell.y);
        Vector3 b = gridManager.GetCellWorldOrigin(
            zoneOriginCell.x + zoneSizeInCells.x - 1,
            zoneOriginCell.y + zoneSizeInCells.y - 1
        );

        float minX = Mathf.Min(a.x, b.x);
        float maxX = Mathf.Max(a.x, b.x) + gridManager.CellSize;
        float minY = Mathf.Min(a.y, b.y);
        float maxY = Mathf.Max(a.y, b.y) + gridManager.CellSize;

        float width = maxX - minX;
        float height = maxY - minY;

        float safeThickness = Mathf.Min(lineThickness, width, height);

        Vector3 worldCenter = new Vector3(
            (minX + maxX) * 0.5f,
            (minY + maxY) * 0.5f,
            zOffset
        );

        transform.position = worldCenter;
        transform.rotation = Quaternion.identity;

        CreateBoxChild(
            "Top",
            new Vector3(0f, (height * 0.5f) - (safeThickness * 0.5f), 0f),
            new Vector3(width, safeThickness, depth),
            color
        );

        CreateBoxChild(
            "Bottom",
            new Vector3(0f, -(height * 0.5f) + (safeThickness * 0.5f), 0f),
            new Vector3(width, safeThickness, depth),
            color
        );

        CreateBoxChild(
            "Left",
            new Vector3(-(width * 0.5f) + (safeThickness * 0.5f), 0f, 0f),
            new Vector3(safeThickness, height, depth),
            color
        );

        CreateBoxChild(
            "Right",
            new Vector3((width * 0.5f) - (safeThickness * 0.5f), 0f, 0f),
            new Vector3(safeThickness, height, depth),
            color
        );
    }

    private void CreateBoxChild(
        string childName,
        Vector3 localPosition,
        Vector3 localScale,
        Color color)
    {
        GameObject child = GameObject.CreatePrimitive(PrimitiveType.Cube);
        child.name = childName;
        child.transform.SetParent(transform, false);
        child.transform.localPosition = localPosition;
        child.transform.localRotation = Quaternion.identity;
        child.transform.localScale = localScale;

        Collider collider = child.GetComponent<Collider>();
        if (collider != null)
        {
            if (Application.isPlaying)
            {
                Destroy(collider);
            }
            else
            {
                DestroyImmediate(collider);
            }
        }

        Renderer renderer = child.GetComponent<Renderer>();
        if (renderer != null)
        {
            Material material = CreateRuntimeMaterial(color);
            renderer.sharedMaterial = material;
            renderer.receiveShadows = false;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        }
    }

    private Material CreateRuntimeMaterial(Color color)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Unlit");
        if (shader == null)
        {
            shader = Shader.Find("Unlit/Color");
        }

        if (shader == null)
        {
            shader = Shader.Find("Standard");
        }

        Material material = new Material(shader);

        if (material.HasProperty("_BaseColor"))
        {
            material.SetColor("_BaseColor", color);
        }

        if (material.HasProperty("_Color"))
        {
            material.SetColor("_Color", color);
        }

        runtimeMaterials.Add(material);
        return material;
    }

    private void ClearChildren()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            GameObject child = transform.GetChild(i).gameObject;

            if (Application.isPlaying)
            {
                Destroy(child);
            }
            else
            {
                DestroyImmediate(child);
            }
        }
    }

    private void OnDestroy()
    {
        for (int i = 0; i < runtimeMaterials.Count; i++)
        {
            if (runtimeMaterials[i] == null)
            {
                continue;
            }

            if (Application.isPlaying)
            {
                Destroy(runtimeMaterials[i]);
            }
            else
            {
                DestroyImmediate(runtimeMaterials[i]);
            }
        }

        runtimeMaterials.Clear();
    }
}