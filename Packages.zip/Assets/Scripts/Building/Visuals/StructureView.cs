using System.Collections.Generic;
using UnityEngine;

public class StructureView : MonoBehaviour
{
    [Header("Debug Info")]
    [SerializeField] private int structureId;
    [SerializeField] private StructureType structureType;
    [SerializeField] private Vector2Int originCell;
    [SerializeField] private Vector2Int sizeInCells;

    private readonly List<Material> runtimeMaterials = new List<Material>();

    public void Initialize(
        PlacedStructure structure,
        GridManager gridManager,
        Color bodyColor,
        Color frontMarkerColor,
        float bodyDepth,
        float zOffset,
        float frontMarkerThickness,
        bool frontMarkerOnPositiveZ)
    {
        structureId = structure.Id;
        structureType = structure.Type;
        originCell = structure.OriginCell;
        sizeInCells = structure.SizeInCells;

        name = $"Structure_{structure.Id}_{structure.Type}";
        transform.rotation = Quaternion.identity;

        BuildVisual(
            structure,
            gridManager,
            bodyColor,
            frontMarkerColor,
            bodyDepth,
            zOffset,
            frontMarkerThickness,
            frontMarkerOnPositiveZ
        );
    }

    private void BuildVisual(
        PlacedStructure structure,
        GridManager gridManager,
        Color bodyColor,
        Color frontMarkerColor,
        float bodyDepth,
        float zOffset,
        float frontMarkerThickness,
        bool frontMarkerOnPositiveZ)
    {
        ClearChildren();

        Vector3 min;
        Vector3 max;
        CalculateWorldRect(structure, gridManager, out min, out max);

        Vector3 worldCenter = new Vector3(
            (min.x + max.x) * 0.5f,
            (min.y + max.y) * 0.5f,
            zOffset
        );

        Vector3 bodySize = new Vector3(
            max.x - min.x,
            max.y - min.y,
            bodyDepth
        );

        transform.position = worldCenter;

        CreateBoxChild(
            "Body",
            Vector3.zero,
            bodySize,
            bodyColor
        );

        float markerLocalZ = (bodyDepth * 0.5f) + (frontMarkerThickness * 0.5f);
        if (!frontMarkerOnPositiveZ)
        {
            markerLocalZ *= -1f;
        }

        CreateBoxChild(
            "FrontMarker",
            new Vector3(0f, 0f, markerLocalZ),
            new Vector3(bodySize.x * 0.92f, bodySize.y * 0.92f, frontMarkerThickness),
            frontMarkerColor
        );
    }

    private void CalculateWorldRect(
        PlacedStructure structure,
        GridManager gridManager,
        out Vector3 min,
        out Vector3 max)
    {
        Vector3 a = gridManager.GetCellWorldOrigin(
            structure.OriginCell.x,
            structure.OriginCell.y
        );

        Vector3 b = gridManager.GetCellWorldOrigin(
            structure.OriginCell.x + structure.WidthInCells - 1,
            structure.OriginCell.y + structure.HeightInCells - 1
        );

        float minX = Mathf.Min(a.x, b.x);
        float maxX = Mathf.Max(a.x, b.x) + gridManager.CellSize;
        float minY = Mathf.Min(a.y, b.y);
        float maxY = Mathf.Max(a.y, b.y) + gridManager.CellSize;

        min = new Vector3(minX, minY, 0f);
        max = new Vector3(maxX, maxY, 0f);
    }

    private void CreateBoxChild(
        string childName,
        Vector3 localPosition,
        Vector3 localScale,
        Color color)
    {
        GameObject child = GameObject.CreatePrimitive(PrimitiveType.Cube);
        child.name = childName;
        child.transform.SetParent(transform, false);
        child.transform.localPosition = localPosition;
        child.transform.localRotation = Quaternion.identity;
        child.transform.localScale = localScale;

        Collider collider = child.GetComponent<Collider>();
        if (collider != null)
        {
            if (Application.isPlaying)
            {
                Destroy(collider);
            }
            else
            {
                DestroyImmediate(collider);
            }
        }

        Renderer renderer = child.GetComponent<Renderer>();
        if (renderer != null)
        {
            Material material = CreateRuntimeMaterial(color);
            renderer.sharedMaterial = material;
            renderer.receiveShadows = false;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        }
    }

    private Material CreateRuntimeMaterial(Color color)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Unlit");
        if (shader == null)
        {
            shader = Shader.Find("Unlit/Color");
        }

        if (shader == null)
        {
            shader = Shader.Find("Standard");
        }

        Material material = new Material(shader);

        if (material.HasProperty("_BaseColor"))
        {
            material.SetColor("_BaseColor", color);
        }

        if (material.HasProperty("_Color"))
        {
            material.SetColor("_Color", color);
        }

        runtimeMaterials.Add(material);
        return material;
    }

    private void ClearChildren()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            GameObject child = transform.GetChild(i).gameObject;

            if (Application.isPlaying)
            {
                Destroy(child);
            }
            else
            {
                DestroyImmediate(child);
            }
        }
    }

    private void OnDestroy()
    {
        for (int i = 0; i < runtimeMaterials.Count; i++)
        {
            if (runtimeMaterials[i] == null)
            {
                continue;
            }

            if (Application.isPlaying)
            {
                Destroy(runtimeMaterials[i]);
            }
            else
            {
                DestroyImmediate(runtimeMaterials[i]);
            }
        }

        runtimeMaterials.Clear();
    }
}