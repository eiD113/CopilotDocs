using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
#endif

namespace Building.Visuals
{
    [DisallowMultipleComponent]
    public sealed class EnvironmentVisualManager : MonoBehaviour
    {
        private const string CellVisualRootName = "CellVisualRoot";
        private const string SurfaceDecorRootName = "SurfaceDecor";
        private const string UndergroundDecorRootName = "UndergroundDecor";

        [Header("References")]
        [SerializeField] private GridManager gridManager;
        [SerializeField] private Transform cellVisualRoot;
        [SerializeField] private Transform surfaceDecorRoot;
        [SerializeField] private Transform undergroundDecorRoot;
        [SerializeField] private CellVisualView cellVisualPrefab;

        [Header("Placement")]
        [SerializeField] private float cellVisualZ = 0f;
        [SerializeField] private bool renameGeneratedObjects = true;
        [SerializeField] private bool snapExistingObjectsWhenRebuildingLookup = false;

        [Header("Debug")]
        [SerializeField] private bool logGeneration = true;
        [SerializeField] private bool logLookupWarnings = true;

        private readonly Dictionary<Vector2Int, CellVisualView> viewsByCell =
            new Dictionary<Vector2Int, CellVisualView>();

        public GridManager GridManager => gridManager;
        public Transform CellVisualRoot => cellVisualRoot;
        public float CellVisualZ => cellVisualZ;

        public bool TryGetCellVisual(int x, int y, out CellVisualView view)
        {
            return viewsByCell.TryGetValue(new Vector2Int(x, y), out view);
        }

        public CellVisualView GetCellVisualOrNull(int x, int y)
        {
            viewsByCell.TryGetValue(new Vector2Int(x, y), out CellVisualView view);
            return view;
        }

        public void SetCellVisible(int x, int y, bool visible)
        {
            if (TryGetCellVisual(x, y, out CellVisualView view))
            {
                view.SetVisible(visible);
            }
        }

        private void Awake()
        {
            RebuildLookup();
        }

        private void OnValidate()
        {
            AutoAssignReferences();
        }

        [ContextMenu("Generate Missing Cell Visuals")]
        public void GenerateMissingCellVisuals()
        {
            if (!EnsureGenerationReferences())
            {
                Debug.LogError($"[{nameof(EnvironmentVisualManager)}] Missing required references for generation.", this);
                return;
            }

            RebuildLookup();

            int createdCount = 0;

            for (int y = 0; y < gridManager.Height; y++)
            {
                for (int x = 0; x < gridManager.Width; x++)
                {
                    if (!ShouldGenerateVisualForCell(x, y))
                    {
                        continue;
                    }

                    Vector2Int key = new Vector2Int(x, y);

                    if (viewsByCell.ContainsKey(key))
                    {
                        continue;
                    }

                    Transform parent = GetParentForCell(y);
                    CellVisualView createdView = CreateCellVisualInstance(parent);

                    if (createdView == null)
                    {
                        Debug.LogError(
                            $"[{nameof(EnvironmentVisualManager)}] Failed to create visual for cell ({x}, {y}).",
                            this
                        );
                        continue;
                    }

                    ConfigureCellVisual(createdView, x, y);
                    viewsByCell[key] = createdView;
                    createdCount++;
                }
            }

            MarkSceneDirtyIfNeeded();

            if (logGeneration)
            {
                Debug.Log(
                    $"[{nameof(EnvironmentVisualManager)}] Generated {createdCount} missing cell visuals.",
                    this
                );
            }
        }

        [ContextMenu("Rebuild Cell Visual Lookup")]
        public void RebuildLookupFromMenu()
        {
            RebuildLookup();

            if (logGeneration)
            {
                Debug.Log(
                    $"[{nameof(EnvironmentVisualManager)}] Rebuilt lookup. Registered {viewsByCell.Count} cell visuals.",
                    this
                );
            }
        }

        [ContextMenu("Snap And Rename Existing Cell Visuals")]
        public void SnapAndRenameExistingCellVisuals()
        {
            if (!EnsureCoreReferences())
            {
                Debug.LogError($"[{nameof(EnvironmentVisualManager)}] Missing required references.", this);
                return;
            }

            CellVisualView[] existingViews = cellVisualRoot.GetComponentsInChildren<CellVisualView>(true);

            int updatedCount = 0;

            for (int i = 0; i < existingViews.Length; i++)
            {
                CellVisualView view = existingViews[i];

                if (view == null)
                {
                    continue;
                }

                ConfigureCellVisual(view, view.GridX, view.GridY);
                updatedCount++;
            }

            RebuildLookup();
            MarkSceneDirtyIfNeeded();

            if (logGeneration)
            {
                Debug.Log(
                    $"[{nameof(EnvironmentVisualManager)}] Snapped and renamed {updatedCount} existing cell visuals.",
                    this
                );
            }
        }

        public void RebuildLookup()
        {
            viewsByCell.Clear();

            if (!EnsureCoreReferences())
            {
                return;
            }

            CellVisualView[] existingViews = cellVisualRoot.GetComponentsInChildren<CellVisualView>(true);

            for (int i = 0; i < existingViews.Length; i++)
            {
                CellVisualView view = existingViews[i];

                if (view == null)
                {
                    continue;
                }

                if (snapExistingObjectsWhenRebuildingLookup)
                {
                    ConfigureCellVisual(view, view.GridX, view.GridY);
                }

                Vector2Int key = new Vector2Int(view.GridX, view.GridY);

                if (viewsByCell.ContainsKey(key))
                {
                    if (logLookupWarnings)
                    {
                        Debug.LogWarning(
                            $"[{nameof(EnvironmentVisualManager)}] Duplicate cell visual detected at ({view.GridX}, {view.GridY}) on object {view.name}.",
                            view
                        );
                    }

                    continue;
                }

                viewsByCell.Add(key, view);
            }
        }

        private bool EnsureCoreReferences()
        {
            AutoAssignReferences();

            return gridManager != null &&
                   cellVisualRoot != null &&
                   surfaceDecorRoot != null &&
                   undergroundDecorRoot != null;
        }

        private bool EnsureGenerationReferences()
        {
            return EnsureCoreReferences() && cellVisualPrefab != null;
        }

        private void AutoAssignReferences()
        {
            if (gridManager == null)
            {
                gridManager = FindFirstObjectByType<GridManager>();
            }

            if (cellVisualRoot == null)
            {
                Transform found = transform.Find(CellVisualRootName);

                if (found != null)
                {
                    cellVisualRoot = found;
                }
            }

            if (cellVisualRoot == null)
            {
                GameObject rootObject = new GameObject(CellVisualRootName);
                rootObject.transform.SetParent(transform, false);
                cellVisualRoot = rootObject.transform;
            }

            if (surfaceDecorRoot == null)
            {
                surfaceDecorRoot = FindOrCreateChild(cellVisualRoot, SurfaceDecorRootName);
            }

            if (undergroundDecorRoot == null)
            {
                undergroundDecorRoot = FindOrCreateChild(cellVisualRoot, UndergroundDecorRootName);
            }
        }

        private Transform FindOrCreateChild(Transform parent, string childName)
        {
            Transform found = parent.Find(childName);

            if (found != null)
            {
                return found;
            }

            GameObject child = new GameObject(childName);
            child.transform.SetParent(parent, false);
            return child.transform;
        }

        private bool ShouldGenerateVisualForCell(int x, int y)
        {
            if (!gridManager.IsInside(x, y))
            {
                return false;
            }

            if (y < gridManager.SurfaceRowY)
            {
                return false;
            }

            if (gridManager.IsInsideBuildArea(x, y))
            {
                return false;
            }

            return true;
        }

        private Transform GetParentForCell(int y)
        {
            if (y == gridManager.SurfaceRowY)
            {
                return surfaceDecorRoot;
            }

            return undergroundDecorRoot;
        }

        private void ConfigureCellVisual(CellVisualView view, int x, int y)
        {
            view.SetGridCoordinates(x, y);

            Vector3 cellCenter = gridManager.GetCellWorldCenter(x, y);
            view.transform.position = new Vector3(cellCenter.x, cellCenter.y, cellVisualZ);
            view.transform.rotation = Quaternion.identity;

            if (renameGeneratedObjects)
            {
                view.RenameToGridCoordinates();
            }

            MoveToCorrectParent(view, y);
            FitViewToCellIfPossible(view);
        }

        private void MoveToCorrectParent(CellVisualView view, int y)
        {
            Transform targetParent = GetParentForCell(y);

            if (view.transform.parent != targetParent)
            {
                view.transform.SetParent(targetParent, true);
            }
        }

        private void FitViewToCellIfPossible(CellVisualView view)
        {
            SpriteRenderer renderer = view.MainRenderer;

            if (renderer == null || renderer.sprite == null)
            {
                return;
            }

            Vector2 spriteWorldSize = renderer.sprite.bounds.size;

            if (spriteWorldSize.x <= 0f || spriteWorldSize.y <= 0f)
            {
                return;
            }

            float targetSize = gridManager.CellSize;

            view.transform.localScale = new Vector3(
                targetSize / spriteWorldSize.x,
                targetSize / spriteWorldSize.y,
                1f
            );
        }

        private CellVisualView CreateCellVisualInstance(Transform parent)
        {
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                Object prefabInstance = PrefabUtility.InstantiatePrefab(cellVisualPrefab.gameObject, parent);

                GameObject instanceObject = prefabInstance as GameObject;
                if (instanceObject != null)
                {
                    Undo.RegisterCreatedObjectUndo(instanceObject, "Generate Cell Visual");
                    return instanceObject.GetComponent<CellVisualView>();
                }

                return null;
            }
#endif

            return Instantiate(cellVisualPrefab, parent);
        }

        private void MarkSceneDirtyIfNeeded()
        {
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                EditorSceneManager.MarkSceneDirty(gameObject.scene);
            }
#endif
        }
    }
}