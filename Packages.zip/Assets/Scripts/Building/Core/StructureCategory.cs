public enum StructureCategory
{
    Elevator,
    Room
}