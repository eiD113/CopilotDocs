public enum StarterStructureRole
{
    None,
    SurfaceStarterElevator,
    UndergroundStarterElevator,
    LeftGuardianZone,
    RightGuardianZone
}
