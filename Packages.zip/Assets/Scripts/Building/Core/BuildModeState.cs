public enum BuildModeState
{
    Off,
    BuildMenuOpen,
    PlacingStructure
}