using UnityEngine;

public class BuildRules : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private GridManager gridManager;

    [Header("Fixed World Rules")]
    [SerializeField] private int surfaceRowY = 6;
    [SerializeField] private int starterLiftGapBelowSurfaceCells = 2;
    [SerializeField] private bool roomsAlwaysFacePlayer = true;

    public int SurfaceRowY => surfaceRowY;
    public bool RoomsAlwaysFacePlayer => roomsAlwaysFacePlayer;

    private void OnValidate()
    {
        if (gridManager == null)
        {
            gridManager = GetComponent<GridManager>();
        }
    }

    public StructureDefinition GetDefinition(StructureType type)
    {
        switch (type)
        {
            case StructureType.Elevator:
                return new StructureDefinition(
                    StructureType.Elevator,
                    StructureCategory.Elevator,
                    2,
                    2,
                    true,
                    true,
                    Color.gray
                );

            case StructureType.Room1:
                return new StructureDefinition(
                    StructureType.Room1,
                    StructureCategory.Room,
                    2,
                    2,
                    true,
                    true,
                    new Color(0.4f, 0.8f, 1f)
                );

            case StructureType.Room2:
                return new StructureDefinition(
                    StructureType.Room2,
                    StructureCategory.Room,
                    4,
                    2,
                    true,
                    true,
                    new Color(1f, 0.85f, 0.25f)
                );

            case StructureType.Room3:
                return new StructureDefinition(
                    StructureType.Room3,
                    StructureCategory.Room,
                    6,
                    2,
                    true,
                    true,
                    new Color(1f, 0.55f, 0.2f)
                );

            case StructureType.StartSurfaceLift:
                return new StructureDefinition(
                    StructureType.StartSurfaceLift,
                    StructureCategory.Elevator,
                    2,
                    2,
                    false,
                    false,
                    new Color(0.60f, 0.60f, 0.68f)
                );

            case StructureType.StartUndergroundLift:
                return new StructureDefinition(
                    StructureType.StartUndergroundLift,
                    StructureCategory.Elevator,
                    2,
                    2,
                    false,
                    false,
                    new Color(0.48f, 0.48f, 0.58f)
                );

            case StructureType.GuardianZone:
                return new StructureDefinition(
                    StructureType.GuardianZone,
                    StructureCategory.Room,
                    6,
                    2,
                    false,
                    false,
                    new Color(0.30f, 0.72f, 0.34f)
                );

            default:
                Debug.LogError($"Unknown StructureType: {type}");
                return null;
        }
    }

    public int GetCenteredStartX(int structureWidthInCells)
    {
        if (gridManager == null)
        {
            Debug.LogError("BuildRules has no GridManager reference.");
            return 0;
        }

        return gridManager.BuildAreaX + ((gridManager.BuildAreaWidth - structureWidthInCells) / 2);
    }

    public Vector2Int GetStarterSurfaceElevatorOrigin()
    {
        StructureDefinition lift = GetDefinition(StructureType.StartSurfaceLift);
        int originX = GetCenteredStartX(lift.WidthInCells);

        // Surface starter lift occupies rows 5 and 6 when surfaceRowY is 6.
        int originY = surfaceRowY - 1;

        return new Vector2Int(originX, originY);
    }

    public Vector2Int GetStarterUndergroundElevatorOrigin()
    {
        StructureDefinition lift = GetDefinition(StructureType.StartUndergroundLift);
        int originX = GetCenteredStartX(lift.WidthInCells);
        int originY = surfaceRowY + 1 + starterLiftGapBelowSurfaceCells;

        return new Vector2Int(originX, originY);
    }

    public Vector2Int GetLeftGuardianZoneOrigin()
    {
        StructureDefinition guardianZone = GetDefinition(StructureType.GuardianZone);
        Vector2Int surfaceLiftOrigin = GetStarterSurfaceElevatorOrigin();

        return new Vector2Int(
            surfaceLiftOrigin.x - guardianZone.WidthInCells,
            surfaceLiftOrigin.y
        );
    }

    public Vector2Int GetRightGuardianZoneOrigin()
    {
        StructureDefinition guardianZone = GetDefinition(StructureType.GuardianZone);
        StructureDefinition surfaceLift = GetDefinition(StructureType.StartSurfaceLift);
        Vector2Int surfaceLiftOrigin = GetStarterSurfaceElevatorOrigin();

        return new Vector2Int(
            surfaceLiftOrigin.x + surfaceLift.WidthInCells,
            surfaceLiftOrigin.y
        );
    }

    [ContextMenu("Log Build Rules")]
    private void LogBuildRules()
    {
        StructureDefinition elevator = GetDefinition(StructureType.Elevator);
        StructureDefinition room1 = GetDefinition(StructureType.Room1);
        StructureDefinition room2 = GetDefinition(StructureType.Room2);
        StructureDefinition room3 = GetDefinition(StructureType.Room3);
        StructureDefinition startSurfaceLift = GetDefinition(StructureType.StartSurfaceLift);
        StructureDefinition startUndergroundLift = GetDefinition(StructureType.StartUndergroundLift);
        StructureDefinition guardianZone = GetDefinition(StructureType.GuardianZone);

        Debug.Log($"Elevator size: {elevator.WidthInCells}x{elevator.HeightInCells}");
        Debug.Log($"Room1 size: {room1.WidthInCells}x{room1.HeightInCells}");
        Debug.Log($"Room2 size: {room2.WidthInCells}x{room2.HeightInCells}");
        Debug.Log($"Room3 size: {room3.WidthInCells}x{room3.HeightInCells}");
        Debug.Log($"StartSurfaceLift size: {startSurfaceLift.WidthInCells}x{startSurfaceLift.HeightInCells}");
        Debug.Log($"StartUndergroundLift size: {startUndergroundLift.WidthInCells}x{startUndergroundLift.HeightInCells}");
        Debug.Log($"GuardianZone size: {guardianZone.WidthInCells}x{guardianZone.HeightInCells}");
        Debug.Log($"Starter surface lift origin: {GetStarterSurfaceElevatorOrigin()}");
        Debug.Log($"Starter underground lift origin: {GetStarterUndergroundElevatorOrigin()}");
        Debug.Log($"Left GuardianZone origin: {GetLeftGuardianZoneOrigin()}");
        Debug.Log($"Right GuardianZone origin: {GetRightGuardianZoneOrigin()}");
        Debug.Log($"Starter lift gap below surface: {starterLiftGapBelowSurfaceCells}");
    }
}
