public enum StructureType
{
    Elevator,
    Room1,
    Room2,
    Room3,
    StartSurfaceLift,
    StartUndergroundLift,
    GuardianZone
}
