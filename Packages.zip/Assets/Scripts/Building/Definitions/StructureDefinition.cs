using UnityEngine;

[System.Serializable]
public class StructureDefinition
{
    public StructureType Type;
    public StructureCategory Category;
    public int WidthInCells;
    public int HeightInCells;
    public bool PlayerCanBuild;
    public bool CanBeRemoved;
    public Color DebugColor;

    public Vector2Int SizeInCells => new Vector2Int(WidthInCells, HeightInCells);

    public StructureDefinition(
        StructureType type,
        StructureCategory category,
        int widthInCells,
        int heightInCells,
        bool playerCanBuild,
        bool canBeRemoved,
        Color debugColor)
    {
        Type = type;
        Category = category;
        WidthInCells = widthInCells;
        HeightInCells = heightInCells;
        PlayerCanBuild = playerCanBuild;
        CanBeRemoved = canBeRemoved;
        DebugColor = debugColor;
    }
}