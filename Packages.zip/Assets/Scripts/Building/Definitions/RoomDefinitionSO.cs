using UnityEngine;

[CreateAssetMenu(fileName = "RoomDefinition", menuName = "Building/Room Definition")]
public class RoomDefinitionSO : ScriptableObject
{
    [Header("Identity")]
    [SerializeField] private string id;
    [SerializeField] private string title;
    [SerializeField] private StructureType structureType;
    [SerializeField] private int sortOrder;

    [Header("Presentation")]
    [SerializeField] private Sprite icon;
    [SerializeField] private int cost;
    [SerializeField] private int requiredLevel;
    [SerializeField] private bool lockedByDefault;

    [Header("Optional UI Data")]
    [SerializeField] private Vector2Int sizeInCells = new Vector2Int(2, 2);

    public string Id => id;
    public string Title => string.IsNullOrWhiteSpace(title) ? structureType.ToString() : title;
    public StructureType StructureType => structureType;
    public int SortOrder => sortOrder;
    public Sprite Icon => icon;
    public int Cost => cost;
    public int RequiredLevel => requiredLevel;
    public bool LockedByDefault => lockedByDefault;
    public Vector2Int SizeInCells => sizeInCells;
}
