using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlacedStructure
{
    public int Id;
    public StructureType Type;
    public StructureCategory Category;
    public Vector2Int OriginCell;
    public int WidthInCells;
    public int HeightInCells;
    public bool PlayerPlaced;
    public bool CanBeRemoved;
    public StarterStructureRole StarterRole;

    public Vector2Int SizeInCells => new Vector2Int(WidthInCells, HeightInCells);

    public bool IsStarterStructure => StarterRole != StarterStructureRole.None;

    public bool IsStarterLift =>
        StarterRole == StarterStructureRole.SurfaceStarterElevator ||
        StarterRole == StarterStructureRole.UndergroundStarterElevator;

    public bool IsGuardianZone =>
        StarterRole == StarterStructureRole.LeftGuardianZone ||
        StarterRole == StarterStructureRole.RightGuardianZone;

    public bool IsFixedStarterStructure => IsStarterStructure;

    public bool IsBuildAnchor =>
        StarterRole == StarterStructureRole.None ||
        StarterRole == StarterStructureRole.UndergroundStarterElevator;

    public bool CanBeMoved => PlayerPlaced && !IsFixedStarterStructure;

    public bool CanBeUpgraded => IsGuardianZone;

    public bool AllowsPlayerInteraction => PlayerPlaced || CanBeUpgraded;

    public CellOccupantType OccupantType
    {
        get
        {
            return Category == StructureCategory.Elevator
                ? CellOccupantType.Elevator
                : CellOccupantType.Room;
        }
    }

    public PlacedStructure(
        int id,
        StructureDefinition definition,
        Vector2Int originCell,
        bool playerPlaced,
        bool canBeRemoved,
        StarterStructureRole starterRole)
    {
        Id = id;
        Type = definition.Type;
        Category = definition.Category;
        OriginCell = originCell;
        WidthInCells = definition.WidthInCells;
        HeightInCells = definition.HeightInCells;
        PlayerPlaced = playerPlaced;
        CanBeRemoved = canBeRemoved;
        StarterRole = starterRole;
    }

    public List<Vector2Int> GetFootprintCells()
    {
        List<Vector2Int> cells = new List<Vector2Int>(WidthInCells * HeightInCells);

        for (int y = 0; y < HeightInCells; y++)
        {
            for (int x = 0; x < WidthInCells; x++)
            {
                cells.Add(new Vector2Int(OriginCell.x + x, OriginCell.y + y));
            }
        }

        return cells;
    }
}
