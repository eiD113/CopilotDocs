using System.Collections.Generic;
using UnityEngine;

public class StructureManager : MonoBehaviour
{
    private const string StructureVisualRootName = "__StructureVisuals";

    private enum NeighborSide
    {
        Left,
        Right,
        Up,
        Down
    }

    [Header("References")]
    [SerializeField] private GridManager gridManager;
    [SerializeField] private BuildRules buildRules;

    [Header("Debug")]
    [SerializeField] private bool logStarterPlacement = true;

    [Header("Rules")]
    [SerializeField] private bool enforceConnectionRulesForPlayerBuilds = true;

    [Header("Visuals")]
    [SerializeField] private bool generateRuntimeVisuals = true;
    [SerializeField] private float structureBodyDepth = 0.60f;
    [SerializeField] private float structureZOffset = 1.00f;
    [SerializeField] private float frontMarkerThickness = 0.08f;
    [SerializeField] private bool frontMarkerOnPositiveZ = true;
    [SerializeField] private Color frontMarkerColor = Color.red;

    [SerializeField] private List<PlacedStructure> placedStructures = new List<PlacedStructure>();
    [SerializeField] private int nextStructureId = 1;

    private Transform structureVisualRoot;

    private void OnValidate()
    {
        if (gridManager == null)
        {
            gridManager = GetComponent<GridManager>();
        }

        if (buildRules == null)
        {
            buildRules = GetComponent<BuildRules>();
        }
    }

    private void Start()
    {
        if (!EnsureReferences())
        {
            return;
        }

        InitializeStarterStructures();
    }

    private bool EnsureReferences()
    {
        if (gridManager == null)
        {
            gridManager = GetComponent<GridManager>();
        }

        if (buildRules == null)
        {
            buildRules = GetComponent<BuildRules>();
        }

        if (gridManager == null || buildRules == null)
        {
            Debug.LogError("StructureManager requires GridManager and BuildRules on the same GameObject.");
            return false;
        }

        return true;
    }

    private void InitializeStarterStructures()
    {
        placedStructures.Clear();
        nextStructureId = 1;

        ClearStructureVisuals();

        Vector2Int surfaceOrigin = buildRules.GetStarterSurfaceElevatorOrigin();
        Vector2Int undergroundOrigin = buildRules.GetStarterUndergroundElevatorOrigin();
        Vector2Int leftGuardianOrigin = buildRules.GetLeftGuardianZoneOrigin();
        Vector2Int rightGuardianOrigin = buildRules.GetRightGuardianZoneOrigin();

        bool surfacePlaced = TryRegisterSystemStructure(
            StructureType.StartSurfaceLift,
            surfaceOrigin,
            false,
            false,
            "StarterSurfaceLift",
            StarterStructureRole.SurfaceStarterElevator
        );

        bool undergroundPlaced = TryRegisterSystemStructure(
            StructureType.StartUndergroundLift,
            undergroundOrigin,
            true,
            false,
            "StarterUndergroundLift",
            StarterStructureRole.UndergroundStarterElevator
        );

        bool leftGuardianPlaced = TryRegisterSystemStructure(
            StructureType.GuardianZone,
            leftGuardianOrigin,
            false,
            false,
            "LeftGuardianZone",
            StarterStructureRole.LeftGuardianZone
        );

        bool rightGuardianPlaced = TryRegisterSystemStructure(
            StructureType.GuardianZone,
            rightGuardianOrigin,
            false,
            false,
            "RightGuardianZone",
            StarterStructureRole.RightGuardianZone
        );

        if (surfacePlaced && undergroundPlaced && leftGuardianPlaced && rightGuardianPlaced && logStarterPlacement)
        {
            Debug.Log("Starter structures initialized successfully.");
        }
    }

    private bool TryRegisterSystemStructure(
        StructureType type,
        Vector2Int originCell,
        bool requireInsideBuildArea,
        bool canBeRemoved,
        string debugName,
        StarterStructureRole starterRole)
    {
        StructureDefinition definition = buildRules.GetDefinition(type);

        if (definition == null)
        {
            Debug.LogError($"Failed to create {debugName}. Definition is null.");
            return false;
        }

        if (!CanPlaceStructure(definition, originCell, requireInsideBuildArea, false, out string failReason))
        {
            Debug.LogError($"Failed to place {debugName}. {failReason}");
            return false;
        }

        int newId = nextStructureId++;

        PlacedStructure structure = new PlacedStructure(
            newId,
            definition,
            originCell,
            false,
            canBeRemoved,
            starterRole
        );

        gridManager.SetAreaOccupant(
            structure.OriginCell.x,
            structure.OriginCell.y,
            structure.WidthInCells,
            structure.HeightInCells,
            structure.OccupantType,
            structure.Id
        );

        placedStructures.Add(structure);
        CreateVisualForStructure(structure, definition);

        if (logStarterPlacement)
        {
            Debug.Log(
                $"{debugName} placed. Id={structure.Id}, Origin={structure.OriginCell}, Size={structure.WidthInCells}x{structure.HeightInCells}"
            );
        }

        return true;
    }

    public bool TryPlacePlayerStructure(StructureType type, Vector2Int originCell, out string failReason)
    {
        failReason = string.Empty;

        if (!EnsureReferences())
        {
            failReason = "Missing required references.";
            return false;
        }

        StructureDefinition definition = buildRules.GetDefinition(type);

        if (definition == null)
        {
            failReason = $"Definition for {type} is null.";
            return false;
        }

        if (!definition.PlayerCanBuild)
        {
            failReason = $"{type} is a fixed system structure and cannot be built by the player.";
            return false;
        }

        if (!CanPlaceStructure(
                definition,
                originCell,
                true,
                enforceConnectionRulesForPlayerBuilds,
                out failReason))
        {
            return false;
        }

        int newId = nextStructureId++;

        PlacedStructure structure = new PlacedStructure(
            newId,
            definition,
            originCell,
            true,
            definition.CanBeRemoved,
            StarterStructureRole.None
        );

        gridManager.SetAreaOccupant(
            structure.OriginCell.x,
            structure.OriginCell.y,
            structure.WidthInCells,
            structure.HeightInCells,
            structure.OccupantType,
            structure.Id
        );

        placedStructures.Add(structure);
        CreateVisualForStructure(structure, definition);
        return true;
    }

    public bool CanPlacePlayerStructure(StructureType type, Vector2Int originCell, out string failReason)
    {
        failReason = string.Empty;

        if (!EnsureReferences())
        {
            failReason = "Missing required references.";
            return false;
        }

        StructureDefinition definition = buildRules.GetDefinition(type);

        if (definition == null)
        {
            failReason = $"Definition for {type} is null.";
            return false;
        }

        if (!definition.PlayerCanBuild)
        {
            failReason = $"{type} is a fixed system structure and cannot be built by the player.";
            return false;
        }

        return CanPlaceStructure(
            definition,
            originCell,
            true,
            enforceConnectionRulesForPlayerBuilds,
            out failReason
        );
    }

    private bool CanPlaceStructure(
        StructureDefinition definition,
        Vector2Int originCell,
        bool requireInsideBuildArea,
        bool enforceConnectionRules,
        out string failReason)
    {
        failReason = string.Empty;

        if (!gridManager.IsAreaInsideGrid(
                originCell.x,
                originCell.y,
                definition.WidthInCells,
                definition.HeightInCells))
        {
            failReason = "Structure footprint is outside the grid.";
            return false;
        }

        if (requireInsideBuildArea &&
            !gridManager.IsAreaInsideBuildArea(
                originCell.x,
                originCell.y,
                definition.WidthInCells,
                definition.HeightInCells))
        {
            failReason = "Structure footprint is outside the build area.";
            return false;
        }

        if (requireInsideBuildArea &&
            !IsOriginAlignedToBuildFloorBand(originCell.y, definition.HeightInCells))
        {
            failReason = "Structure must start on a valid 2-cell floor band inside the build area.";
            return false;
        }

        if (!gridManager.IsAreaFree(
                originCell.x,
                originCell.y,
                definition.WidthInCells,
                definition.HeightInCells))
        {
            failReason = "One or more cells are already occupied.";
            return false;
        }

        if (enforceConnectionRules &&
            !SatisfiesConnectionRules(definition, originCell, out failReason))
        {
            return false;
        }

        return true;
    }

    private bool IsOriginAlignedToBuildFloorBand(int originY, int heightInCells)
    {
        if (heightInCells != 2)
        {
            return false;
        }

        int relativeY = originY - gridManager.BuildAreaY;

        if (relativeY < 0)
        {
            return false;
        }

        return relativeY % 2 == 0;
    }

    private bool SatisfiesConnectionRules(
        StructureDefinition definition,
        Vector2Int originCell,
        out string failReason)
    {
        failReason = string.Empty;

        bool touchedAnyExistingStructure = false;
        bool hasValidConnection = false;

        int leftX = originCell.x;
        int rightX = originCell.x + definition.WidthInCells - 1;
        int topY = originCell.y;
        int bottomY = originCell.y + definition.HeightInCells - 1;

        for (int y = topY; y <= bottomY; y++)
        {
            EvaluateNeighborCell(
                leftX - 1,
                y,
                NeighborSide.Left,
                definition,
                originCell,
                ref touchedAnyExistingStructure,
                ref hasValidConnection
            );

            EvaluateNeighborCell(
                rightX + 1,
                y,
                NeighborSide.Right,
                definition,
                originCell,
                ref touchedAnyExistingStructure,
                ref hasValidConnection
            );
        }

        for (int x = leftX; x <= rightX; x++)
        {
            EvaluateNeighborCell(
                x,
                topY - 1,
                NeighborSide.Up,
                definition,
                originCell,
                ref touchedAnyExistingStructure,
                ref hasValidConnection
            );

            EvaluateNeighborCell(
                x,
                bottomY + 1,
                NeighborSide.Down,
                definition,
                originCell,
                ref touchedAnyExistingStructure,
                ref hasValidConnection
            );
        }

        if (hasValidConnection)
        {
            return true;
        }

        if (!touchedAnyExistingStructure)
        {
            failReason = "Structure must connect to an existing structure.";
            return false;
        }

        failReason = GetInvalidConnectionReason(definition);
        return false;
    }

    private void EvaluateNeighborCell(
        int x,
        int y,
        NeighborSide touchedSide,
        StructureDefinition newDefinition,
        Vector2Int newOriginCell,
        ref bool touchedAnyExistingStructure,
        ref bool hasValidConnection)
    {
        if (hasValidConnection)
        {
            return;
        }

        if (!gridManager.IsInside(x, y))
        {
            return;
        }

        GridCell cell = gridManager.GetCell(x, y);
        if (cell.OccupantType == CellOccupantType.None || cell.OccupantId <= 0)
        {
            return;
        }

        PlacedStructure neighbor = GetStructureById(cell.OccupantId);
        if (neighbor == null)
        {
            return;
        }

        touchedAnyExistingStructure = true;

        if (IsNeighborValidAnchor(neighbor, newDefinition, newOriginCell, touchedSide))
        {
            hasValidConnection = true;
        }
    }

    private bool IsNeighborValidAnchor(
        PlacedStructure neighbor,
        StructureDefinition newDefinition,
        Vector2Int newOriginCell,
        NeighborSide touchedSide)
    {
        if (!neighbor.IsBuildAnchor)
        {
            return false;
        }

        if (newDefinition.Category == StructureCategory.Room)
        {
            return touchedSide == NeighborSide.Left || touchedSide == NeighborSide.Right;
        }

        if (newDefinition.Category == StructureCategory.Elevator)
        {
            if (touchedSide == NeighborSide.Left || touchedSide == NeighborSide.Right)
            {
                return true;
            }

            if (touchedSide == NeighborSide.Up && neighbor.Category == StructureCategory.Elevator)
            {
                return IsDirectlyBelowSameElevatorColumn(neighbor, newOriginCell, newDefinition);
            }

            return false;
        }

        return false;
    }

    private bool IsDirectlyBelowSameElevatorColumn(
        PlacedStructure upperElevator,
        Vector2Int newOriginCell,
        StructureDefinition newDefinition)
    {
        if (upperElevator.Category != StructureCategory.Elevator)
        {
            return false;
        }

        if (newDefinition.Category != StructureCategory.Elevator)
        {
            return false;
        }

        if (upperElevator.WidthInCells != newDefinition.WidthInCells)
        {
            return false;
        }

        bool sameColumn = newOriginCell.x == upperElevator.OriginCell.x;
        bool directlyBelow = newOriginCell.y == upperElevator.OriginCell.y + upperElevator.HeightInCells;

        return sameColumn && directlyBelow;
    }

    private string GetInvalidConnectionReason(StructureDefinition definition)
    {
        if (definition.Category == StructureCategory.Room)
        {
            return "Rooms must connect on the left or right side of an existing room or elevator.";
        }

        if (definition.Category == StructureCategory.Elevator)
        {
            return "Elevators must connect on the left/right side of an existing structure, or be placed directly below an existing elevator.";
        }

        return "Structure connection rules were not satisfied.";
    }

    public bool CanRemoveStructure(int structureId, out string failReason)
    {
        failReason = string.Empty;

        if (!EnsureReferences())
        {
            failReason = "Missing required references.";
            return false;
        }

        PlacedStructure structure = GetStructureById(structureId);
        if (structure == null)
        {
            failReason = $"Structure with id {structureId} was not found.";
            return false;
        }

        if (structure.IsStarterLift)
        {
            failReason = "Starter lifts are fixed starter structures and cannot be removed.";
            return false;
        }

        if (structure.IsGuardianZone)
        {
            failReason = "Guardian zones are fixed starter structures. They can be upgraded later, but they cannot be removed.";
            return false;
        }

        if (!structure.CanBeRemoved)
        {
            failReason = "This structure cannot be removed.";
            return false;
        }

        return true;
    }

    public bool CanMoveStructure(int structureId, out string failReason)
    {
        failReason = string.Empty;

        if (!EnsureReferences())
        {
            failReason = "Missing required references.";
            return false;
        }

        PlacedStructure structure = GetStructureById(structureId);
        if (structure == null)
        {
            failReason = $"Structure with id {structureId} was not found.";
            return false;
        }

        if (structure.IsStarterLift)
        {
            failReason = "Starter lifts are fixed starter structures and cannot be moved.";
            return false;
        }

        if (structure.IsGuardianZone)
        {
            failReason = "Guardian zones are fixed starter structures. They can be upgraded later, but they cannot be moved.";
            return false;
        }

        if (!structure.CanBeMoved)
        {
            failReason = "This structure cannot be moved.";
            return false;
        }

        return true;
    }

    public bool CanUpgradeStructure(int structureId, out string failReason)
    {
        failReason = string.Empty;

        if (!EnsureReferences())
        {
            failReason = "Missing required references.";
            return false;
        }

        PlacedStructure structure = GetStructureById(structureId);
        if (structure == null)
        {
            failReason = $"Structure with id {structureId} was not found.";
            return false;
        }

        if (structure.IsGuardianZone)
        {
            return true;
        }

        if (structure.IsStarterLift)
        {
            failReason = "Starter lifts do not support upgrades.";
            return false;
        }

        failReason = "This structure has no upgrade logic.";
        return false;
    }

    private void CreateVisualForStructure(PlacedStructure structure, StructureDefinition definition)
    {
        if (!generateRuntimeVisuals)
        {
            return;
        }

        EnsureStructureVisualRoot();

        GameObject viewObject = new GameObject($"Structure_{structure.Id}_{structure.Type}");
        viewObject.transform.SetParent(structureVisualRoot, false);

        StructureView view = viewObject.AddComponent<StructureView>();
        view.Initialize(
            structure,
            gridManager,
            definition.DebugColor,
            frontMarkerColor,
            structureBodyDepth,
            structureZOffset,
            frontMarkerThickness,
            frontMarkerOnPositiveZ
        );
    }

    private void EnsureStructureVisualRoot()
    {
        if (structureVisualRoot != null)
        {
            return;
        }

        Transform found = transform.Find(StructureVisualRootName);
        if (found != null)
        {
            structureVisualRoot = found;
            return;
        }

        GameObject root = new GameObject(StructureVisualRootName);
        root.transform.SetParent(transform, false);
        structureVisualRoot = root.transform;
    }

    private void ClearStructureVisuals()
    {
        if (structureVisualRoot == null)
        {
            Transform found = transform.Find(StructureVisualRootName);
            if (found != null)
            {
                structureVisualRoot = found;
            }
        }

        if (structureVisualRoot == null)
        {
            return;
        }

        for (int i = structureVisualRoot.childCount - 1; i >= 0; i--)
        {
            GameObject child = structureVisualRoot.GetChild(i).gameObject;

            if (Application.isPlaying)
            {
                Destroy(child);
            }
            else
            {
                DestroyImmediate(child);
            }
        }
    }

    public PlacedStructure GetStructureById(int structureId)
    {
        for (int i = 0; i < placedStructures.Count; i++)
        {
            if (placedStructures[i].Id == structureId)
            {
                return placedStructures[i];
            }
        }

        return null;
    }
}
