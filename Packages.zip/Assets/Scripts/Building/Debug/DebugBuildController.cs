using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;

public class DebugBuildController : MonoBehaviour
{
    private const string PlacementZonesRootName = "__BuildPlacementZones";

    [Header("References")]
    [SerializeField] private GridManager gridManager;
    [SerializeField] private BuildRules buildRules;
    [SerializeField] private StructureManager structureManager;
    [SerializeField] private Camera targetCamera;

    [Header("Build Mode")]
    [SerializeField] private bool debugPlacementEnabled = true;
    [SerializeField] private BuildModeState buildModeState = BuildModeState.Off;
    [SerializeField] private StructureType selectedStructureType = StructureType.Room1;
    [SerializeField] private bool allowDebugSelectionHotkeys = true;
    [SerializeField] private bool exitBuildModeAfterSuccessfulPlacement = true;
    [SerializeField] private bool logBuildModeChanges = true;
    [SerializeField] private bool logSelectionChanges = true;
    [SerializeField] private bool logPlacementResults = true;

    [Header("Placement Zones")]
    [SerializeField] private bool showPlacementZones = true;
    [SerializeField] private float placementZoneZOffset = 2.00f;
    [SerializeField] private float placementZoneLineThickness = 0.12f;
    [SerializeField] private float placementZoneDepth = 0.06f;
    [SerializeField] private Color placementZoneColor = Color.green;

    private Transform placementZonesRoot;
    private bool placementZonesDirty = true;

    public BuildModeState CurrentBuildModeState => buildModeState;
    public StructureType SelectedStructureType => selectedStructureType;
    public bool IsBuildModeActive => buildModeState != BuildModeState.Off;
    public bool IsPlacingStructure => buildModeState == BuildModeState.PlacingStructure;

    public event Action<BuildModeState, StructureType> BuildUiStateChanged;

    private void OnValidate()
    {
        if (gridManager == null)
        {
            gridManager = GetComponent<GridManager>();
        }

        if (buildRules == null)
        {
            buildRules = GetComponent<BuildRules>();
        }

        if (structureManager == null)
        {
            structureManager = GetComponent<StructureManager>();
        }

        if (targetCamera == null && Camera.main != null)
        {
            targetCamera = Camera.main;
        }

        placementZonesDirty = true;
    }

    private void Update()
    {
        if (!debugPlacementEnabled)
        {
            SetBuildModeState(BuildModeState.Off, false);
            ClearPlacementZones();
            return;
        }

        if (!EnsureReferences())
        {
            SetBuildModeState(BuildModeState.Off, false);
            ClearPlacementZones();
            return;
        }

        HandleSelectionHotkeys();
        RebuildPlacementZonesIfDirty();

        if (buildModeState == BuildModeState.PlacingStructure)
        {
            HandlePlacementClick();
        }
    }

    public void OpenBuildMenu()
    {
        if (!debugPlacementEnabled || !EnsureReferences())
        {
            return;
        }

        SetBuildModeState(BuildModeState.BuildMenuOpen);
    }

    public void BeginPlacingStructure(StructureType structureType)
    {
        if (!debugPlacementEnabled || !EnsureReferences())
        {
            return;
        }

        SetSelectedStructureType(structureType);
        SetBuildModeState(BuildModeState.PlacingStructure);
    }

    public void ReturnToBuildMenu()
    {
        if (!debugPlacementEnabled || !EnsureReferences())
        {
            return;
        }

        SetBuildModeState(BuildModeState.BuildMenuOpen);
    }

    public void ExitBuildMode()
    {
        SetBuildModeState(BuildModeState.Off);
    }

    private bool EnsureReferences()
    {
        if (gridManager == null)
        {
            gridManager = GetComponent<GridManager>();
        }

        if (buildRules == null)
        {
            buildRules = GetComponent<BuildRules>();
        }

        if (structureManager == null)
        {
            structureManager = GetComponent<StructureManager>();
        }

        if (targetCamera == null)
        {
            targetCamera = Camera.main;
        }

        return gridManager != null &&
               buildRules != null &&
               structureManager != null &&
               targetCamera != null;
    }

    private void HandleSelectionHotkeys()
    {
        if (!allowDebugSelectionHotkeys || buildModeState == BuildModeState.Off)
        {
            return;
        }

        Keyboard keyboard = Keyboard.current;
        if (keyboard == null)
        {
            return;
        }

        if (keyboard.digit1Key.wasPressedThisFrame)
        {
            BeginPlacingStructure(StructureType.Elevator);
        }
        else if (keyboard.digit2Key.wasPressedThisFrame)
        {
            BeginPlacingStructure(StructureType.Room1);
        }
        else if (keyboard.digit3Key.wasPressedThisFrame)
        {
            BeginPlacingStructure(StructureType.Room2);
        }
        else if (keyboard.digit4Key.wasPressedThisFrame)
        {
            BeginPlacingStructure(StructureType.Room3);
        }
    }

    private void SetSelectedStructureType(StructureType newType)
    {
        if (selectedStructureType == newType)
        {
            return;
        }

        selectedStructureType = newType;
        placementZonesDirty = true;

        if (logSelectionChanges)
        {
            Debug.Log($"Selected structure type: {selectedStructureType}");
        }

        NotifyBuildUiStateChanged();
    }

    private void SetBuildModeState(BuildModeState newState, bool logChange = true)
    {
        if (buildModeState == newState)
        {
            return;
        }

        buildModeState = newState;
        placementZonesDirty = true;

        if (buildModeState == BuildModeState.Off)
        {
            ClearPlacementZones();
        }

        if (logChange && logBuildModeChanges)
        {
            Debug.Log($"Build mode changed: {buildModeState}");
        }

        NotifyBuildUiStateChanged();
    }

    private void NotifyBuildUiStateChanged()
    {
        BuildUiStateChanged?.Invoke(buildModeState, selectedStructureType);
    }

    private void RebuildPlacementZonesIfDirty()
    {
        if (!placementZonesDirty)
        {
            return;
        }

        placementZonesDirty = false;
        RebuildPlacementZones();
    }

    private void RebuildPlacementZones()
    {
        ClearPlacementZones();

        if (!ShouldShowPlacementZones())
        {
            return;
        }

        StructureDefinition definition = buildRules.GetDefinition(selectedStructureType);
        if (definition == null)
        {
            return;
        }

        EnsurePlacementZonesRoot();

        int minOriginX = gridManager.BuildAreaX;
        int maxOriginX = gridManager.BuildAreaX + gridManager.BuildAreaWidth - definition.WidthInCells;
        int maxOriginY = gridManager.BuildAreaY + gridManager.BuildAreaHeight - definition.HeightInCells;

        for (int originY = gridManager.BuildAreaY; originY <= maxOriginY; originY += 2)
        {
            for (int originX = minOriginX; originX <= maxOriginX; originX++)
            {
                Vector2Int candidateOrigin = new Vector2Int(originX, originY);

                if (!structureManager.CanPlacePlayerStructure(selectedStructureType, candidateOrigin, out _))
                {
                    continue;
                }

                CreatePlacementZone(candidateOrigin, definition.SizeInCells);
            }
        }
    }

    private bool ShouldShowPlacementZones()
    {
        if (!showPlacementZones)
        {
            return false;
        }

        return buildModeState == BuildModeState.PlacingStructure;
    }

    private void CreatePlacementZone(Vector2Int originCell, Vector2Int sizeInCells)
    {
        EnsurePlacementZonesRoot();

        GameObject zoneObject = new GameObject($"Zone_{originCell.x}_{originCell.y}");
        zoneObject.transform.SetParent(placementZonesRoot, false);

        BuildPlacementZoneView zoneView = zoneObject.AddComponent<BuildPlacementZoneView>();
        zoneView.Initialize(
            gridManager,
            originCell,
            sizeInCells,
            placementZoneZOffset,
            placementZoneLineThickness,
            placementZoneDepth,
            placementZoneColor
        );
    }

    private void HandlePlacementClick()
    {
        Mouse mouse = Mouse.current;
        if (mouse == null || !mouse.leftButton.wasPressedThisFrame)
        {
            return;
        }

        if (IsPointerOverUI())
        {
            return;
        }

        if (!TryGetMouseWorldPointOnGridPlane(out Vector3 worldPoint))
        {
            return;
        }

        if (!gridManager.TryGetCellFromWorldPoint(worldPoint, out Vector2Int clickedCell))
        {
            return;
        }

        StructureDefinition definition = buildRules.GetDefinition(selectedStructureType);
        if (definition == null)
        {
            return;
        }

        if (!TryResolvePlacementOriginFromClickedCell(
                clickedCell,
                definition,
                out Vector2Int resolvedOrigin,
                out _))
        {
            return;
        }

        bool placed = structureManager.TryPlacePlayerStructure(
            selectedStructureType,
            resolvedOrigin,
            out string failReason
        );

        if (placed)
        {
            if (logPlacementResults)
            {
                Debug.Log(
                    $"Placed {selectedStructureType}. ClickedCell={clickedCell}, ResolvedOrigin={resolvedOrigin}, Size={definition.WidthInCells}x{definition.HeightInCells}"
                );
            }

            if (exitBuildModeAfterSuccessfulPlacement)
            {
                ExitBuildMode();
            }
            else
            {
                placementZonesDirty = true;
            }
        }
        else if (logPlacementResults)
        {
            Debug.Log(
                $"Placement rejected for {selectedStructureType}. ClickedCell={clickedCell}, ResolvedOrigin={resolvedOrigin}. Reason: {failReason}"
            );
        }
    }

    private bool IsPointerOverUI()
    {
        if (EventSystem.current == null)
        {
            return false;
        }

        return EventSystem.current.IsPointerOverGameObject();
    }

    private bool TryResolvePlacementOriginFromClickedCell(
        Vector2Int clickedCell,
        StructureDefinition definition,
        out Vector2Int resolvedOrigin,
        out string failReason)
    {
        resolvedOrigin = default;
        failReason = "No valid placement candidate contains the clicked cell.";

        int snappedY = SnapYToBuildFloorBand(clickedCell.y);

        bool foundAnyCandidate = false;
        bool foundValidCandidate = false;
        int bestScore = int.MaxValue;

        for (int originX = clickedCell.x - (definition.WidthInCells - 1); originX <= clickedCell.x; originX++)
        {
            Vector2Int candidateOrigin = new Vector2Int(originX, snappedY);

            if (!DoesFootprintContainClickedCell(candidateOrigin, definition, clickedCell))
            {
                continue;
            }

            foundAnyCandidate = true;

            if (structureManager.CanPlacePlayerStructure(selectedStructureType, candidateOrigin, out _))
            {
                int candidateScore = ScorePlacementCandidate(candidateOrigin, definition, clickedCell);

                if (!foundValidCandidate ||
                    candidateScore < bestScore ||
                    (candidateScore == bestScore && candidateOrigin.x < resolvedOrigin.x))
                {
                    foundValidCandidate = true;
                    bestScore = candidateScore;
                    resolvedOrigin = candidateOrigin;
                }
            }
        }

        if (foundValidCandidate)
        {
            return true;
        }

        if (!foundAnyCandidate)
        {
            failReason = "Clicked cell does not belong to any possible footprint for this structure.";
            return false;
        }

        failReason = "Clicked cell is not inside any currently valid placement zone.";
        return false;
    }

    private bool DoesFootprintContainClickedCell(
        Vector2Int originCell,
        StructureDefinition definition,
        Vector2Int clickedCell)
    {
        return clickedCell.x >= originCell.x &&
               clickedCell.x < originCell.x + definition.WidthInCells &&
               clickedCell.y >= originCell.y &&
               clickedCell.y < originCell.y + definition.HeightInCells;
    }

    private int ScorePlacementCandidate(
        Vector2Int originCell,
        StructureDefinition definition,
        Vector2Int clickedCell)
    {
        int minX = originCell.x;
        int maxX = originCell.x + definition.WidthInCells - 1;

        int footprintCenterTimesTwo = minX + maxX;
        int clickedCenterTimesTwo = clickedCell.x * 2;

        int centerDistanceScore = Mathf.Abs(footprintCenterTimesTwo - clickedCenterTimesTwo);
        int originDistanceScore = Mathf.Abs(originCell.x - clickedCell.x);

        return (centerDistanceScore * 100) + originDistanceScore;
    }

    private int SnapYToBuildFloorBand(int clickedY)
    {
        int relativeY = clickedY - gridManager.BuildAreaY;
        int floorIndex = Mathf.FloorToInt(relativeY / 2f);

        return gridManager.BuildAreaY + (floorIndex * 2);
    }

    private bool TryGetMouseWorldPointOnGridPlane(out Vector3 worldPoint)
    {
        worldPoint = default;

        Ray ray = targetCamera.ScreenPointToRay(Mouse.current.position.ReadValue());
        Plane plane = new Plane(
            gridManager.GetGridPlaneNormal(),
            gridManager.GetGridPlaneWorldPosition()
        );

        if (!plane.Raycast(ray, out float enter))
        {
            return false;
        }

        worldPoint = ray.GetPoint(enter);
        return true;
    }

    private void EnsurePlacementZonesRoot()
    {
        if (placementZonesRoot != null)
        {
            return;
        }

        Transform found = transform.Find(PlacementZonesRootName);
        if (found != null)
        {
            placementZonesRoot = found;
            return;
        }

        GameObject root = new GameObject(PlacementZonesRootName);
        root.transform.SetParent(transform, false);
        placementZonesRoot = root.transform;
    }

    private void ClearPlacementZones()
    {
        if (placementZonesRoot == null)
        {
            Transform found = transform.Find(PlacementZonesRootName);
            if (found != null)
            {
                placementZonesRoot = found;
            }
        }

        if (placementZonesRoot == null)
        {
            return;
        }

        for (int i = placementZonesRoot.childCount - 1; i >= 0; i--)
        {
            Transform child = placementZonesRoot.GetChild(i);

            if (Application.isPlaying)
            {
                Destroy(child.gameObject);
            }
            else
            {
                DestroyImmediate(child.gameObject);
            }
        }
    }
}
