using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(Image))]
public class BuildStructureCard : MonoBehaviour,
    IPointerDownHandler,
    IPointerUpHandler,
    IInitializePotentialDragHandler,
    IBeginDragHandler,
    IDragHandler,
    IEndDragHandler
{
    [Header("Data")]
    [SerializeField] private StructureType structureType;
    [SerializeField] private bool isLocked;

    [Header("References")]
    [SerializeField] private BuildModeSimpleUI owner;
    [SerializeField] private ScrollRect scrollRect;
    [SerializeField] private Image backgroundImage;
    [SerializeField] private Image iconImage;
    [SerializeField] private Text titleText;
    [SerializeField] private Text costText;
    [SerializeField] private GameObject lockRoot;
    [SerializeField] private Text requiredLevelText;

    [Header("Visuals")]
    [SerializeField] private Color normalColor = new Color(1f, 1f, 1f, 0.92f);
    [SerializeField] private Color selectedColor = new Color(0.72f, 0.92f, 0.72f, 1f);
    [SerializeField] private Color lockedColor = new Color(0.75f, 0.75f, 0.75f, 0.9f);

    [Header("Interaction")]
    [SerializeField] private float tapMaxDragDistance = 18f;

    private Vector2 pointerDownPosition;
    private bool wasDragged;

    public StructureType StructureType => structureType;

    private void OnValidate()
    {
        ResolveReferences();
        DisableLegacyButtonIfPresent();
        DisableChildRaycasts();
        RefreshVisualState(false);
    }

    private void Awake()
    {
        ResolveReferences();
        DisableLegacyButtonIfPresent();
        DisableChildRaycasts();
        RefreshVisualState(false);
    }

    public void Bind(
        BuildModeSimpleUI newOwner,
        ScrollRect newScrollRect,
        StructureType newStructureType,
        string newTitle,
        Sprite newIcon,
        int newCost,
        int newRequiredLevel,
        bool newIsLocked)
    {
        owner = newOwner;
        scrollRect = newScrollRect;
        structureType = newStructureType;
        isLocked = newIsLocked;
        gameObject.name = $"{newStructureType}Card";

        ResolveReferences();

        if (titleText != null)
        {
            titleText.text = newTitle;
        }

        if (costText != null)
        {
            costText.text = newCost > 0 ? newCost.ToString() : string.Empty;
            costText.gameObject.SetActive(newCost > 0);
        }

        if (requiredLevelText != null)
        {
            requiredLevelText.text = newRequiredLevel > 0 ? $"Lvl {newRequiredLevel}" : string.Empty;
            requiredLevelText.gameObject.SetActive(newIsLocked && newRequiredLevel > 0);
        }

        if (iconImage != null)
        {
            iconImage.sprite = newIcon;
            iconImage.enabled = newIcon != null;
        }

        if (lockRoot != null)
        {
            lockRoot.SetActive(newIsLocked);
        }

        RefreshVisualState(false);
    }

    public void SetSelected(bool isSelected)
    {
        RefreshVisualState(isSelected);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        pointerDownPosition = eventData.position;
        wasDragged = false;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (owner == null || isLocked)
        {
            return;
        }

        float dragDistance = Vector2.Distance(pointerDownPosition, eventData.position);

        if (!wasDragged && dragDistance <= tapMaxDragDistance)
        {
            owner.SelectStructure(structureType);
        }
    }

    public void OnInitializePotentialDrag(PointerEventData eventData)
    {
        if (scrollRect != null)
        {
            scrollRect.OnInitializePotentialDrag(eventData);
        }
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        wasDragged = true;

        if (scrollRect != null)
        {
            scrollRect.OnBeginDrag(eventData);
        }
    }

    public void OnDrag(PointerEventData eventData)
    {
        wasDragged = true;

        if (scrollRect != null)
        {
            scrollRect.OnDrag(eventData);
        }
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        if (scrollRect != null)
        {
            scrollRect.OnEndDrag(eventData);
        }
    }

    private void ResolveReferences()
    {
        if (owner == null)
        {
            owner = GetComponentInParent<BuildModeSimpleUI>(true);
        }

        if (scrollRect == null)
        {
            scrollRect = GetComponentInParent<ScrollRect>(true);
        }

        if (backgroundImage == null)
        {
            backgroundImage = GetComponent<Image>();
        }

        if (titleText == null)
        {
            titleText = FindTextByName("title", "name");

            if (titleText == null)
            {
                Text[] texts = GetComponentsInChildren<Text>(true);
                if (texts.Length > 0)
                {
                    titleText = texts[0];
                }
            }
        }

        if (costText == null)
        {
            costText = FindTextByName("cost", "price");
        }

        if (requiredLevelText == null)
        {
            requiredLevelText = FindTextByName("level", "lvl");
        }

        if (iconImage == null)
        {
            Image[] images = GetComponentsInChildren<Image>(true);
            for (int i = 0; i < images.Length; i++)
            {
                if (images[i] != backgroundImage)
                {
                    iconImage = images[i];
                    break;
                }
            }
        }

        if (lockRoot == null)
        {
            lockRoot = FindChildByName("lock", "locked");
        }
    }

    private Text FindTextByName(params string[] nameParts)
    {
        Text[] texts = GetComponentsInChildren<Text>(true);

        for (int i = 0; i < texts.Length; i++)
        {
            string childName = texts[i].gameObject.name.ToLowerInvariant();

            for (int j = 0; j < nameParts.Length; j++)
            {
                if (childName.Contains(nameParts[j]))
                {
                    return texts[i];
                }
            }
        }

        return null;
    }

    private GameObject FindChildByName(params string[] nameParts)
    {
        Transform[] children = GetComponentsInChildren<Transform>(true);

        for (int i = 0; i < children.Length; i++)
        {
            string childName = children[i].gameObject.name.ToLowerInvariant();

            for (int j = 0; j < nameParts.Length; j++)
            {
                if (childName.Contains(nameParts[j]))
                {
                    return children[i].gameObject;
                }
            }
        }

        return null;
    }

    private void RefreshVisualState(bool isSelected)
    {
        if (backgroundImage == null)
        {
            return;
        }

        if (isLocked)
        {
            backgroundImage.color = lockedColor;
            return;
        }

        backgroundImage.color = isSelected ? selectedColor : normalColor;
    }

    private void DisableLegacyButtonIfPresent()
    {
        Button legacyButton = GetComponent<Button>();
        if (legacyButton != null)
        {
            legacyButton.enabled = false;
        }
    }

    private void DisableChildRaycasts()
    {
        Graphic[] graphics = GetComponentsInChildren<Graphic>(true);

        for (int i = 0; i < graphics.Length; i++)
        {
            Graphic graphic = graphics[i];

            if (graphic == backgroundImage)
            {
                graphic.raycastTarget = true;
                continue;
            }

            graphic.raycastTarget = false;
        }
    }
}
