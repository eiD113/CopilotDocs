using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BuildModeSimpleUI : MonoBehaviour
{
    private struct RuntimeCardData
    {
        public readonly string Title;
        public readonly Sprite Icon;
        public readonly int Cost;
        public readonly int RequiredLevel;
        public readonly bool IsLocked;
        public readonly StructureType StructureType;
        public readonly int SortOrder;

        public RuntimeCardData(
            string title,
            Sprite icon,
            int cost,
            int requiredLevel,
            bool isLocked,
            StructureType structureType,
            int sortOrder)
        {
            Title = title;
            Icon = icon;
            Cost = cost;
            RequiredLevel = requiredLevel;
            IsLocked = isLocked;
            StructureType = structureType;
            SortOrder = sortOrder;
        }
    }

    [Header("References")]
    [SerializeField] private DebugBuildController buildController;
    [SerializeField] private Button buildButton;
    [SerializeField] private GameObject buildMenuPanel;
    [SerializeField] private Button cancelButton;
    [SerializeField] private Button placementCancelButton;

    [Header("Menu Data")]
    [SerializeField] private RoomDefinitionSO[] roomDefinitions;
    [SerializeField] private BuildStructureCard cardTemplate;
    [SerializeField] private bool useFallbackCardsWhenNoDefinitions = true;

    [Header("Auto-resolved")]
    [SerializeField] private ScrollRect structureScrollView;
    [SerializeField] private RectTransform viewport;
    [SerializeField] private RectTransform content;
    [SerializeField] private BuildStructureCard[] structureCards;

    [Header("Panel Layout")]
    [SerializeField, Range(0f, 1f)] private float panelMinY = 0.12f;
    [SerializeField, Range(0f, 1f)] private float panelMaxY = 0.34f;

    [Header("Inner Layout")]
    [SerializeField] private float scrollLeftPadding = 20f;
    [SerializeField] private float scrollRightPadding = 20f;
    [SerializeField] private float scrollTopPadding = 16f;
    [SerializeField] private float scrollBottomPadding = 16f;

    [Header("Cancel Layout")]
    [SerializeField] private float cancelWidth = 64f;
    [SerializeField] private float cancelHeight = 64f;
    [SerializeField] private float cancelRightMargin = 20f;
    [SerializeField] private float cancelTopMargin = 20f;

    [Header("Card Layout")]
    [SerializeField] private float cardWidth = 220f;
    [SerializeField] private float cardHeight = 120f;
    [SerializeField] private float cardSpacing = 16f;

    [Header("Debug")]
    [SerializeField] private bool rebuildCardsOnAwake = true;
    [SerializeField] private bool logUiActions = true;

    private readonly List<BuildStructureCard> spawnedCards = new List<BuildStructureCard>();
    private DebugBuildController subscribedController;
    private bool listenersRegistered;

    private void OnValidate()
    {
        ResolveReferences();
        EnsureLayoutComponents();
        ApplyRuntimeLikeLayout();
        ResolveCardTemplate();
    }

    private void Awake()
    {
        ResolveReferences();
        EnsureLayoutComponents();
        ApplyRuntimeLikeLayout();
        EnsurePlacementCancelButtonExists();
        ResolveCardTemplate();

        if (rebuildCardsOnAwake)
        {
            RebuildCards();
        }

        RegisterButtonListeners();
        RefreshUI();
    }

    private void OnEnable()
    {
        SubscribeToBuildController();
        RefreshUI();
    }

    private void OnDisable()
    {
        UnsubscribeFromBuildController();
    }

    private void OnDestroy()
    {
        UnregisterButtonListeners();
        UnsubscribeFromBuildController();
    }

    public void SelectStructure(StructureType structureType)
    {
        if (buildController == null)
        {
            Debug.LogWarning("BuildModeSimpleUI: DebugBuildController is missing.");
            return;
        }

        buildController.BeginPlacingStructure(structureType);

        if (logUiActions)
        {
            Debug.Log($"BuildModeSimpleUI -> BeginPlacingStructure({structureType})");
        }

        RefreshUI();
    }

    [ContextMenu("Rebuild Cards")]
    public void RebuildCards()
    {
        ResolveReferences();
        ResolveCardTemplate();

        if (content == null)
        {
            Debug.LogWarning("BuildModeSimpleUI: Content is missing. Cannot rebuild cards.");
            return;
        }

        if (cardTemplate == null)
        {
            Debug.LogWarning("BuildModeSimpleUI: Card template is missing. Cannot rebuild cards.");
            return;
        }

        ClearGeneratedCards();
        DestroyLegacyCardsExceptTemplate();

        List<RuntimeCardData> runtimeData = BuildRuntimeDataList();
        runtimeData.Sort((a, b) => a.SortOrder.CompareTo(b.SortOrder));

        cardTemplate.gameObject.SetActive(false);

        for (int i = 0; i < runtimeData.Count; i++)
        {
            RuntimeCardData data = runtimeData[i];
            BuildStructureCard newCard = Instantiate(cardTemplate, content);
            newCard.gameObject.SetActive(true);
            newCard.Bind(
                this,
                structureScrollView,
                data.StructureType,
                data.Title,
                data.Icon,
                data.Cost,
                data.RequiredLevel,
                data.IsLocked
            );

            ConfigureSingleCardLayout(newCard);
            spawnedCards.Add(newCard);
        }

        structureCards = spawnedCards.ToArray();

        LayoutRebuilder.ForceRebuildLayoutImmediate(content);

        if (structureScrollView != null)
        {
            structureScrollView.horizontalNormalizedPosition = 0f;
        }

        RefreshUI();
    }

    private List<RuntimeCardData> BuildRuntimeDataList()
    {
        List<RuntimeCardData> data = new List<RuntimeCardData>();

        if (roomDefinitions != null)
        {
            for (int i = 0; i < roomDefinitions.Length; i++)
            {
                RoomDefinitionSO definition = roomDefinitions[i];
                if (definition == null)
                {
                    continue;
                }

                data.Add(new RuntimeCardData(
                    definition.Title,
                    definition.Icon,
                    definition.Cost,
                    definition.RequiredLevel,
                    definition.LockedByDefault,
                    definition.StructureType,
                    definition.SortOrder
                ));
            }
        }

        if (data.Count == 0 && useFallbackCardsWhenNoDefinitions)
        {
            data.Add(new RuntimeCardData("Elevator", null, 0, 0, false, StructureType.Elevator, 0));
            data.Add(new RuntimeCardData("Room 1", null, 0, 0, false, StructureType.Room1, 1));
            data.Add(new RuntimeCardData("Room 2", null, 0, 0, false, StructureType.Room2, 2));
            data.Add(new RuntimeCardData("Room 3", null, 0, 0, false, StructureType.Room3, 3));
        }

        return data;
    }

    private void OnBuildButtonClicked()
    {
        if (buildController == null)
        {
            Debug.LogWarning("BuildModeSimpleUI: DebugBuildController is missing.");
            return;
        }

        buildController.OpenBuildMenu();

        if (logUiActions)
        {
            Debug.Log("BuildModeSimpleUI -> OpenBuildMenu()");
        }

        RefreshUI();
    }

    private void OnMenuCancelButtonClicked()
    {
        if (buildController == null)
        {
            Debug.LogWarning("BuildModeSimpleUI: DebugBuildController is missing.");
            return;
        }

        buildController.ExitBuildMode();

        if (logUiActions)
        {
            Debug.Log("BuildModeSimpleUI -> ExitBuildMode() from menu close button");
        }

        RefreshUI();
    }

    private void OnPlacementCancelButtonClicked()
    {
        if (buildController == null)
        {
            Debug.LogWarning("BuildModeSimpleUI: DebugBuildController is missing.");
            return;
        }

        buildController.ExitBuildMode();

        if (logUiActions)
        {
            Debug.Log("BuildModeSimpleUI -> ExitBuildMode() from placement cancel button");
        }

        RefreshUI();
    }

private void RefreshUI()
{
    BuildModeState currentState = BuildModeState.Off;

    if (buildController != null)
    {
        currentState = buildController.CurrentBuildModeState;
    }

    bool isOff = currentState == BuildModeState.Off;
    bool isMenuOpen = currentState == BuildModeState.BuildMenuOpen;
    bool isPlacing = currentState == BuildModeState.PlacingStructure;

    if (buildButton != null)
    {
        buildButton.gameObject.SetActive(isOff);
    }

    if (buildMenuPanel != null)
    {
        buildMenuPanel.SetActive(isMenuOpen);
    }

    if (cancelButton != null)
    {
        cancelButton.gameObject.SetActive(isMenuOpen);
    }

    if (placementCancelButton != null)
    {
        placementCancelButton.gameObject.SetActive(isPlacing);
    }

    // Cards in the build menu should never keep a remembered selected state.
    UpdateCardSelection(false, StructureType.Room1);
}

private void UpdateCardSelection(bool showSelection, StructureType selectedType)
{
    if (structureCards == null)
    {
        return;
    }

    for (int i = 0; i < structureCards.Length; i++)
    {
        BuildStructureCard card = structureCards[i];
        if (card == null)
        {
            continue;
        }

        bool isSelected = showSelection && card.StructureType == selectedType;
        card.SetSelected(isSelected);
    }
}



    private void OnBuildControllerStateChanged(BuildModeState _, StructureType __)
    {
        RefreshUI();
    }

    private void ResolveReferences()
    {
        if (buildController == null)
        {
            buildController = FindFirstObjectByType<DebugBuildController>();
        }

        if (buildMenuPanel == null)
        {
            Transform found = transform.Find("BuildMenuPanel");
            if (found != null)
            {
                buildMenuPanel = found.gameObject;
            }
        }

        if (buildButton == null)
        {
            Transform found = transform.Find("BuildButton");
            if (found != null)
            {
                buildButton = found.GetComponent<Button>();
            }
        }

        if (cancelButton == null && buildMenuPanel != null)
        {
            Transform found = buildMenuPanel.transform.Find("CancelButton");
            if (found != null)
            {
                cancelButton = found.GetComponent<Button>();
            }
        }

        if (structureScrollView == null && buildMenuPanel != null)
        {
            structureScrollView = buildMenuPanel.GetComponentInChildren<ScrollRect>(true);
        }

        if (viewport == null && structureScrollView != null)
        {
            viewport = structureScrollView.viewport;
        }

        if (content == null && structureScrollView != null)
        {
            content = structureScrollView.content;
        }

        if (placementCancelButton == null)
        {
            Transform found = transform.Find("PlacementCancelButton");
            if (found != null)
            {
                placementCancelButton = found.GetComponent<Button>();
            }
        }
    }

    private void EnsureLayoutComponents()
    {
        if (content == null)
        {
            return;
        }

        HorizontalLayoutGroup layoutGroup = content.GetComponent<HorizontalLayoutGroup>();
        if (layoutGroup == null)
        {
            layoutGroup = content.gameObject.AddComponent<HorizontalLayoutGroup>();
        }

        layoutGroup.childAlignment = TextAnchor.MiddleLeft;
        layoutGroup.spacing = cardSpacing;
        layoutGroup.childControlWidth = false;
        layoutGroup.childControlHeight = true;
        layoutGroup.childForceExpandWidth = false;
        layoutGroup.childForceExpandHeight = false;
        layoutGroup.padding = new RectOffset(0, 0, 0, 0);

        ContentSizeFitter fitter = content.GetComponent<ContentSizeFitter>();
        if (fitter == null)
        {
            fitter = content.gameObject.AddComponent<ContentSizeFitter>();
        }

        fitter.horizontalFit = ContentSizeFitter.FitMode.PreferredSize;
        fitter.verticalFit = ContentSizeFitter.FitMode.Unconstrained;

        if (viewport != null && viewport.GetComponent<RectMask2D>() == null)
        {
            viewport.gameObject.AddComponent<RectMask2D>();
        }

        if (structureScrollView != null)
        {
            structureScrollView.horizontal = true;
            structureScrollView.vertical = false;
            structureScrollView.movementType = ScrollRect.MovementType.Clamped;
            structureScrollView.inertia = true;
            structureScrollView.scrollSensitivity = 25f;
            structureScrollView.horizontalScrollbar = null;
            structureScrollView.verticalScrollbar = null;
        }
    }

    private void ApplyRuntimeLikeLayout()
    {
        if (buildMenuPanel != null)
        {
            RectTransform panelRect = buildMenuPanel.GetComponent<RectTransform>();
            if (panelRect != null)
            {
                panelRect.anchorMin = new Vector2(0f, panelMinY);
                panelRect.anchorMax = new Vector2(1f, panelMaxY);
                panelRect.pivot = new Vector2(0.5f, 0.5f);
                panelRect.offsetMin = Vector2.zero;
                panelRect.offsetMax = Vector2.zero;
                panelRect.anchoredPosition = Vector2.zero;
            }
        }

        if (cancelButton != null)
        {
            RectTransform cancelRect = cancelButton.GetComponent<RectTransform>();
            if (cancelRect != null)
            {
                cancelRect.anchorMin = new Vector2(1f, 1f);
                cancelRect.anchorMax = new Vector2(1f, 1f);
                cancelRect.pivot = new Vector2(1f, 1f);
                cancelRect.sizeDelta = new Vector2(cancelWidth, cancelHeight);
                cancelRect.anchoredPosition = new Vector2(-cancelRightMargin, -cancelTopMargin);
            }
        }

        if (structureScrollView != null)
        {
            RectTransform scrollRect = structureScrollView.GetComponent<RectTransform>();
            if (scrollRect != null)
            {
                scrollRect.anchorMin = new Vector2(0f, 0f);
                scrollRect.anchorMax = new Vector2(1f, 1f);
                scrollRect.pivot = new Vector2(0.5f, 0.5f);
                scrollRect.offsetMin = new Vector2(scrollLeftPadding, scrollBottomPadding);
                scrollRect.offsetMax = new Vector2(-scrollRightPadding, -scrollTopPadding);
            }
        }

        if (viewport != null)
        {
            viewport.anchorMin = new Vector2(0f, 0f);
            viewport.anchorMax = new Vector2(1f, 1f);
            viewport.pivot = new Vector2(0.5f, 0.5f);
            viewport.offsetMin = Vector2.zero;
            viewport.offsetMax = Vector2.zero;
        }

        if (content != null)
        {
            content.anchorMin = new Vector2(0f, 0f);
            content.anchorMax = new Vector2(0f, 1f);
            content.pivot = new Vector2(0f, 0.5f);
            content.offsetMin = Vector2.zero;
            content.offsetMax = Vector2.zero;
            content.anchoredPosition = Vector2.zero;
        }

        if (placementCancelButton != null)
        {
            RectTransform cancelRect = placementCancelButton.GetComponent<RectTransform>();
            if (cancelRect != null)
            {
                cancelRect.anchorMin = new Vector2(1f, 1f);
                cancelRect.anchorMax = new Vector2(1f, 1f);
                cancelRect.pivot = new Vector2(1f, 1f);
                cancelRect.sizeDelta = new Vector2(cancelWidth, cancelHeight);
                cancelRect.anchoredPosition = new Vector2(-cancelRightMargin, -cancelTopMargin);
            }
        }
    }

    private void ResolveCardTemplate()
    {
        if (cardTemplate != null)
        {
            return;
        }

        if (content != null)
        {
            BuildStructureCard[] cards = content.GetComponentsInChildren<BuildStructureCard>(true);
            if (cards.Length > 0)
            {
                cardTemplate = cards[0];
            }
        }
    }

    private void EnsurePlacementCancelButtonExists()
    {
        if (placementCancelButton != null || cancelButton == null)
        {
            return;
        }

        if (!Application.isPlaying)
        {
            return;
        }

        Canvas parentCanvas = GetComponentInParent<Canvas>(true);
        Transform parent = parentCanvas != null ? parentCanvas.transform : transform;

        Button newButton = Instantiate(cancelButton, parent);
        newButton.name = "PlacementCancelButton";
        newButton.onClick.RemoveAllListeners();

        placementCancelButton = newButton;
        placementCancelButton.gameObject.SetActive(false);

        Text label = placementCancelButton.GetComponentInChildren<Text>(true);
        if (label != null)
        {
            label.text = "X";
        }

        Image image = placementCancelButton.GetComponent<Image>();
        if (image != null)
        {
            image.raycastTarget = true;
        }

        ApplyRuntimeLikeLayout();
    }

    private void ConfigureSingleCardLayout(BuildStructureCard card)
    {
        if (card == null)
        {
            return;
        }

        LayoutElement layoutElement = card.GetComponent<LayoutElement>();
        if (layoutElement == null)
        {
            layoutElement = card.gameObject.AddComponent<LayoutElement>();
        }

        layoutElement.minWidth = cardWidth;
        layoutElement.preferredWidth = cardWidth;
        layoutElement.flexibleWidth = 0f;
        layoutElement.minHeight = cardHeight;
        layoutElement.preferredHeight = cardHeight;
        layoutElement.flexibleHeight = 0f;
    }

    private void ClearGeneratedCards()
    {
        for (int i = 0; i < spawnedCards.Count; i++)
        {
            if (spawnedCards[i] != null)
            {
                if (Application.isPlaying)
                {
                    Destroy(spawnedCards[i].gameObject);
                }
                else
                {
                    DestroyImmediate(spawnedCards[i].gameObject);
                }
            }
        }

        spawnedCards.Clear();
    }

    private void DestroyLegacyCardsExceptTemplate()
    {
        if (content == null)
        {
            return;
        }

        BuildStructureCard[] allCards = content.GetComponentsInChildren<BuildStructureCard>(true);
        for (int i = 0; i < allCards.Length; i++)
        {
            if (allCards[i] == null || allCards[i] == cardTemplate)
            {
                continue;
            }

            if (Application.isPlaying)
            {
                Destroy(allCards[i].gameObject);
            }
            else
            {
                DestroyImmediate(allCards[i].gameObject);
            }
        }
    }

    private void SubscribeToBuildController()
    {
        ResolveReferences();

        if (buildController == null)
        {
            return;
        }

        if (subscribedController == buildController)
        {
            return;
        }

        UnsubscribeFromBuildController();

        subscribedController = buildController;
        subscribedController.BuildUiStateChanged += OnBuildControllerStateChanged;
    }

    private void UnsubscribeFromBuildController()
    {
        if (subscribedController == null)
        {
            return;
        }

        subscribedController.BuildUiStateChanged -= OnBuildControllerStateChanged;
        subscribedController = null;
    }

    private void RegisterButtonListeners()
    {
        if (listenersRegistered)
        {
            return;
        }

        if (buildButton != null)
        {
            buildButton.onClick.AddListener(OnBuildButtonClicked);
        }

        if (cancelButton != null)
        {
            cancelButton.onClick.AddListener(OnMenuCancelButtonClicked);
        }

        if (placementCancelButton != null)
        {
            placementCancelButton.onClick.AddListener(OnPlacementCancelButtonClicked);
        }

        listenersRegistered = true;
    }

    private void UnregisterButtonListeners()
    {
        if (!listenersRegistered)
        {
            return;
        }

        if (buildButton != null)
        {
            buildButton.onClick.RemoveListener(OnBuildButtonClicked);
        }

        if (cancelButton != null)
        {
            cancelButton.onClick.RemoveListener(OnMenuCancelButtonClicked);
        }

        if (placementCancelButton != null)
        {
            placementCancelButton.onClick.RemoveListener(OnPlacementCancelButtonClicked);
        }

        listenersRegistered = false;
    }
}
